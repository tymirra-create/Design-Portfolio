# Images Directory

This directory contains all the images used in Tymirra Smith's UX Portfolio website.

## Directory Structure

```
public/images/
├── profile/
│   └── tymirra-headshot.png           # Professional headshot (400x400px recommended)
└── case-studies/
    ├── her-heart/
    │   ├── goal.png                   # HerHeart App goal definition
    │   ├── background-research.png    # Background research findings
    │   ├── quiz-design.png           # Quiz interface design
    │   ├── summary-design.png        # Summary screen design
    │   ├── prototype-revisions-1.png # First prototype iteration
    │   ├── prototype-revisions-2.png # Second prototype iteration
    │   ├── recommendation-ideation.png # Recommendation system ideation
    │   └── recommendation-design.png  # Recommendation system final design
    ├── window-nation/
    │   ├── start-page.png            # Booking platform start page
    │   ├── quote-form.png            # Quote request form interface
    │   ├── count-interface.png       # Window counting interface
    │   └── booking-system.png        # Final booking system
    ├── servicemaster/
    │   ├── dashboard-1.png           # Form optimization dashboard view 1
    │   └── dashboard-2.png           # Form optimization dashboard view 2
    └── microsoft-crm/
        ├── queue-view.png            # CRM queue management interface
        └── details-view.png          # CRM detailed record view
```

## Image Requirements

### Profile Image
- **File**: `profile/tymirra-headshot.png`
- **Dimensions**: 400x400px (square format)
- **Format**: PNG or JPG
- **Description**: Professional headshot in white t-shirt with warm smile in modern office setting

### Case Study Images
- **Dimensions**: 800x600px recommended (4:3 aspect ratio)
- **Format**: PNG or JPG
- **Quality**: High resolution for crisp display on all devices

## How to Replace Placeholder Files

1. **Replace each placeholder file** with your actual images
2. **Keep the same file names** to maintain code references
3. **Maintain recommended dimensions** for optimal display
4. **Use PNG format** for images with transparency or screenshots
5. **Use JPG format** for photographs to reduce file size

## Important Notes

- All placeholder files currently contain text descriptions instead of actual images
- The website will display broken image icons until actual images are uploaded
- Images are referenced from the React components using these exact paths
- All images are served from the `/public/images/` directory in production

## Upload Instructions

When uploading to GitHub:
1. Replace each placeholder file with your actual image
2. Commit and push the changes
3. The images will be automatically served in production via Vercel