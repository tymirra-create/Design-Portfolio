# Image Replacement Guide

This guide explains how to replace the placeholder image files with your actual case study images.

## Quick Reference

### Profile Image
- **Location**: `/public/images/profile/tymirra-headshot.png`
- **Size**: 400x400px (square)
- **Used in**: Hero section

### HerHeart App Images
- `/public/images/case-studies/her-heart/goal.png`
- `/public/images/case-studies/her-heart/background-research.png`
- `/public/images/case-studies/her-heart/quiz-design.png`
- `/public/images/case-studies/her-heart/summary-design.png`
- `/public/images/case-studies/her-heart/prototype-revisions-1.png`
- `/public/images/case-studies/her-heart/prototype-revisions-2.png`
- `/public/images/case-studies/her-heart/recommendation-ideation.png`
- `/public/images/case-studies/her-heart/recommendation-design.png`

### Window Nation Images
- `/public/images/case-studies/window-nation/start-page.png`
- `/public/images/case-studies/window-nation/quote-form.png`
- `/public/images/case-studies/window-nation/count-interface.png`
- `/public/images/case-studies/window-nation/booking-system.png`

### ServiceMaster Images
- `/public/images/case-studies/servicemaster/dashboard-1.png`
- `/public/images/case-studies/servicemaster/dashboard-2.png`

### Microsoft CRM Images
- `/public/images/case-studies/microsoft-crm/queue-view.png`
- `/public/images/case-studies/microsoft-crm/details-view.png`

## Replacement Process

### Using GitHub Web Interface
1. Navigate to the specific image file in GitHub
2. Click the "Edit" button (pencil icon)
3. Click "Upload files" 
4. Drag and drop your replacement image
5. Make sure the filename matches exactly
6. Commit the changes

### Using Git Commands
```bash
# Replace a specific image (example)
cp /path/to/your/actual-image.png /public/images/profile/tymirra-headshot.png

# Add and commit
git add public/images/
git commit -m "Replace placeholder images with actual portfolio images"
git push origin main
```

## Image Specifications

### General Requirements
- **Format**: PNG (preferred) or JPG
- **Quality**: High resolution for crisp display
- **Compression**: Optimize for web (balance quality vs file size)

### Specific Dimensions
- **Profile image**: 400x400px (1:1 ratio)
- **Case study images**: 800x600px (4:3 ratio) recommended
- **Screenshots**: Use actual dimensions, but optimize file size

## Important Notes

⚠️ **Keep exact filenames** - The React components reference these specific paths
⚠️ **Maintain directory structure** - Don't change folder organization
⚠️ **Optimize file sizes** - Large images will slow down your site
✅ **Test locally** - Verify images display correctly before pushing

## After Replacement

1. **Commit changes** to GitHub
2. **Vercel will auto-deploy** your updates
3. **Check your live site** to ensure images load properly
4. **Images will cache** - you may need to hard refresh (Ctrl+F5) to see changes

## Troubleshooting

**Images not showing?**
- Check file paths match exactly
- Verify file extensions are correct (.png vs .jpg)
- Ensure files are in the `/public/` directory
- Clear browser cache and reload

**Images loading slowly?**
- Compress images using tools like TinyPNG
- Consider converting large PNGs to JPG format
- Optimize images for web before uploading