import { Card, CardContent, CardHeader, CardTitle } from "./ui/card.tsx";
import { Button } from "./ui/button.tsx";
import { ImageIcon, Navigation, Presentation } from "lucide-react";

interface SlideshowInstructionsProps {
  onClose: () => void;
}

export function SlideshowInstructions({ onClose }: SlideshowInstructionsProps) {
  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Presentation className="w-6 h-6 text-primary" />
            Portfolio Slideshow Instructions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Navigation className="w-5 h-5 text-teal mt-1" />
              <div>
                <h4 className="mb-1">Navigation</h4>
                <p className="text-muted-foreground">
                  Use the Previous/Next buttons or click the dots to navigate between slides. 
                  Each case study is broken into logical sections for easy presentation.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <ImageIcon className="w-5 h-5 text-terracotta mt-1" />
              <div>
                <h4 className="mb-1">Design Images</h4>
                <p className="text-muted-foreground">
                  Each slide has designated spaces (dashed border boxes) where you can insert your 
                  design screenshots, wireframes, user flows, and other visual materials. Simply 
                  replace the placeholder areas with your actual design images.
                </p>
              </div>
            </div>
            
            <div className="bg-muted/50 p-4 rounded-lg">
              <h4 className="mb-2">Suggested Images by Slide Type:</h4>
              <ul className="text-muted-foreground space-y-1 text-sm">
                <li>• <strong>Overview:</strong> Project hero images, key screenshots</li>
                <li>• <strong>Challenge:</strong> Current state flows, pain point diagrams</li>
                <li>• <strong>Process:</strong> Research documentation, wireframes</li>
                <li>• <strong>Solution:</strong> Final designs, user interface mockups</li>
                <li>• <strong>Results:</strong> Before/after comparisons, analytics</li>
              </ul>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button onClick={onClose}>
              Got it, let's start!
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}