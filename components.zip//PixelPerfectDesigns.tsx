import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ExternalLink, Eye, Palette, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function PixelPerfectDesigns() {
  const designs = [
    {
      title: "Window Nation Booking Platform",
      company: "Window Nation",
      description: "A comprehensive design system and booking platform that generated $3.5M in revenue. Every pixel crafted to optimize conversion and user experience.",
      image: "https://images.unsplash.com/photo-1643781410046-421dd014f743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kb3clMjBob21lJTIwaW1wcm92ZW1lbnQlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4MDM3MDE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      figmaUrl: "https://www.figma.com/deck/mgxwJFmkrorBKWAzQDJW4Q/Design-Review?node-id=1-511&viewport=-107%2C-42%2C0.51&t=kLdlKwO0RI70hCjQ-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1",
      type: "Design System & Platform",
      impact: "$3.5M Revenue Impact",
      colorScheme: "burgundy",
      highlights: [
        "Responsive design system",
        "Appointment booking flow",
        "Lead capture optimization",
        "Microsoft Dynamics integration"
      ]
    },
    {
      title: "My Credit Approve Platform",
      company: "Credit Services",
      description: "A sleek, user-friendly credit approval platform designed with precision and attention to detail. Focus on accessibility and conversion optimization.",
      image: "https://images.unsplash.com/photo-1757301714935-c8127a21abc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVkaXQlMjBmaW5hbmNpYWwlMjBhcHAlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4MDM3MDE4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      figmaUrl: "https://visor-found-65128644.figma.site/",
      type: "Financial Platform",
      impact: "Credit Dispute Flow",
      colorScheme: "teal",
      highlights: [
        "Clean, modern interface",
        "Step-by-step approval process",
        "Mobile-first design",
        "Accessibility focused"
      ]
    }
  ];

  return (
    <section id="pixel-perfect" className="py-20 px-6 bg-gradient-to-b from-muted/5 to-muted/20">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
            <Palette className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary">Pixel Perfect</span>
          </div>
          <h2 className="mb-4">Precision Design Showcase</h2>
          <p className="text-muted-foreground max-w-3xl mx-auto">
            Every pixel matters. Here are detailed design explorations showcasing my commitment to 
            pixel-perfect execution, comprehensive design systems, and measurable business impact.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {designs.map((design, index) => (
            <Card key={index} className={`overflow-hidden border-2 hover:shadow-xl transition-all duration-300 group ${
              design.colorScheme === 'burgundy' ? 'border-burgundy/20 hover:border-burgundy/40' : 'border-teal/20 hover:border-teal/40'
            }`}>
              <div className="relative overflow-hidden">
                <ImageWithFallback
                  src={design.image}
                  alt={`${design.title} design preview`}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge 
                    variant="secondary" 
                    className={`${design.colorScheme === 'burgundy' ? 'bg-burgundy/90 text-white' : 'bg-teal/90 text-white'} backdrop-blur-sm`}
                  >
                    {design.type}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <div className={`w-10 h-10 rounded-full ${
                    design.colorScheme === 'burgundy' ? 'bg-burgundy/90' : 'bg-teal/90'
                  } flex items-center justify-center backdrop-blur-sm`}>
                    <Eye className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>

              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">{design.title}</CardTitle>
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="outline" className="text-xs">
                        {design.company}
                      </Badge>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${
                          design.colorScheme === 'burgundy' ? 'bg-burgundy/10 text-burgundy' : 'bg-teal/10 text-teal'
                        }`}
                      >
                        {design.impact}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {design.description}
                </p>

                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-primary" />
                      Design Highlights
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {design.highlights.map((highlight, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <div className={`w-1.5 h-1.5 rounded-full ${
                            design.colorScheme === 'burgundy' ? 'bg-burgundy' : 'bg-teal'
                          }`}></div>
                          <span className="text-sm">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-muted">
                    <Button 
                      asChild 
                      className={`w-full ${
                        design.colorScheme === 'burgundy' ? 'bg-burgundy hover:bg-burgundy/90' : 'bg-teal hover:bg-teal/90'
                      } text-white`}
                    >
                      <a 
                        href={design.figmaUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View in Figma
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Card className="bg-primary/5 border-primary/20 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl mb-4">Attention to Detail</h3>
              <p className="text-muted-foreground leading-relaxed">
                These designs represent hundreds of hours of iteration, user testing, and refinement. 
                Every element is purposefully placed to maximize user experience and business outcomes.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}