import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Mail, MapPin, Calendar, Download, ExternalLink, Presentation } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-20 px-6 bg-muted/10">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="mb-4">Let's Connect</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Ready to discuss how strategic design can drive your business forward? 
            I'd love to hear about your challenges and explore how we can solve them together.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="space-y-6">
            <Card className="border-l-4 border-l-primary">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Get In Touch</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Email</p>
                      <a href="mailto:tymirra@gmail.com" className="text-primary hover:underline">
                        tymirra@gmail.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-muted-foreground">Atlanta, GA</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Availability</p>
                      <p className="text-muted-foreground">Open to new opportunities</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">What I'm Looking For</h3>
                <div className="space-y-3">
                  <Badge variant="outline" className="w-full justify-start py-2">
                    Senior Product Designer roles
                  </Badge>
                  <Badge variant="outline" className="w-full justify-start py-2">
                    UX Research leadership positions
                  </Badge>
                  <Badge variant="outline" className="w-full justify-start py-2">
                    Healthcare technology opportunities
                  </Badge>
                  <Badge variant="outline" className="w-full justify-start py-2">
                    Enterprise software design roles
                  </Badge>
                  <Badge variant="outline" className="w-full justify-start py-2">
                    Consulting & fractional design work
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Ready to Start a Conversation?</h3>
                <p className="text-muted-foreground mb-6">
                  Whether you're looking to fill a design role, discuss a project, or just chat 
                  about UX challenges, I'd love to connect. I typically respond within 24 hours.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button asChild size="lg" className="flex-1">
                    <a href="mailto:tymirra@gmail.com?subject=Let's Discuss Your Design Needs">
                      <Mail className="w-4 h-4 mr-2" />
                      Send Message
                    </a>
                  </Button>
                  <Button variant="outline" asChild size="lg" className="flex-1">
                    <a href="mailto:tymirra@gmail.com?subject=Schedule a Call">
                      <Calendar className="w-4 h-4 mr-2" />
                      Schedule Call
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Before You Reach Out</h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <p className="font-medium mb-1">For hiring managers:</p>
                    <p className="text-muted-foreground">
                      Please include role details, team size, and key challenges you're facing. 
                      Happy to discuss how my experience aligns with your needs.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium mb-1">For project collaborations:</p>
                    <p className="text-muted-foreground">
                      I'm selective about consulting work but love tackling complex UX challenges. 
                      Tell me about your project and timeline.
                    </p>
                  </div>
                  <div>
                    <p className="font-medium mb-1">For case study access:</p>
                    <p className="text-muted-foreground">
                      Detailed case studies are password protected. Include your name, company, 
                      and role when requesting access.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Slideshow Access */}
        <div className="mt-16 text-center">
          <Card className="bg-terracotta/10 border-terracotta/30 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 bg-terracotta/20 rounded-full flex items-center justify-center">
                  <Presentation className="w-8 h-8 text-terracotta" />
                </div>
              </div>
              <h3 className="font-semibold mb-3 text-burgundy">Interview Presentation</h3>
              <p className="text-muted-foreground mb-6">
                View my portfolio in slideshow format - perfect for interviews and presentations. 
                Focused on UI deliverables, accessibility expertise, and developer handoff excellence.
              </p>
              <Button 
                onClick={() => window.location.href = '?slideshow=true'}
                size="lg"
                className="bg-terracotta hover:bg-terracotta/90 text-white"
              >
                <Presentation className="w-4 h-4 mr-2" />
                Launch Interview Slideshow
              </Button>
              <p className="text-xs text-muted-foreground mt-3">
                Use keyboard navigation: Arrow keys, spacebar, or number keys (1-9)
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}