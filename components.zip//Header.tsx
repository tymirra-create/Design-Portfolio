import { useState } from "react";
import { Button } from "./ui/button.tsx";
import { Badge } from "./ui/badge.tsx";
import { Menu, X, FileText, Download } from "lucide-react";
import { useAuth } from "./useAuth.tsx";

interface HeaderProps {
  onTogglePDFGenerator?: () => void;
  showPDFGenerator?: boolean;
}

export function Header({ 
  onTogglePDFGenerator,
  showPDFGenerator = false
}: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated } = useAuth();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const handlePDFGenerator = () => {
    if (onTogglePDFGenerator) {
      onTogglePDFGenerator();
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-b border-border z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h1 className="text-xl font-semibold text-primary">Tymirra Smith</h1>
            <span className="text-sm text-muted-foreground">UX Designer</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            <button
              onClick={() => scrollToSection('experience')}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Experience
            </button>
            <button
              onClick={() => scrollToSection('case-studies')}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Case Studies
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Contact
            </button>

            {/* Authenticated Features */}
            {isAuthenticated && (
              <>
                <div className="w-px h-6 bg-border mx-2" />
                <button
                  onClick={handlePDFGenerator}
                  className={`flex items-center gap-2 px-3 py-1.5 text-sm rounded-md transition-colors ${
                    showPDFGenerator 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  <Download className="w-4 h-4" />
                  PDF Downloads
                </button>
              </>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            {isAuthenticated && (
              <Badge variant="secondary" className="text-xs">
                Authenticated
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="lg:hidden mt-4 pb-4 space-y-4 border-t border-border pt-4">
            <button
              onClick={() => scrollToSection('experience')}
              className="block w-full text-left py-2 text-muted-foreground hover:text-foreground"
            >
              Experience
            </button>
            <button
              onClick={() => scrollToSection('case-studies')}
              className="block w-full text-left py-2 text-muted-foreground hover:text-foreground"
            >
              Case Studies
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="block w-full text-left py-2 text-muted-foreground hover:text-foreground"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block w-full text-left py-2 text-muted-foreground hover:text-foreground"
            >
              Contact
            </button>

            {/* Authenticated Mobile Features */}
            {isAuthenticated && (
              <>
                <div className="border-t border-border pt-4 mt-4">
                  <div className="text-sm font-medium text-muted-foreground mb-3">Protected Features</div>
                  
                  <button
                    onClick={handlePDFGenerator}
                    className={`flex items-center gap-3 w-full text-left py-2 transition-colors ${
                      showPDFGenerator ? 'text-primary font-medium' : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                    PDF Downloads
                  </button>
                </div>
              </>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}