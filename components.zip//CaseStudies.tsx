import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Button } from "./ui/button";
import { 
  Heart, 
  Brain, 
  TrendingUp, 
  Users, 
  DollarSign, 
  ExternalLink,
  Award,
  Clock,
  Target,
  ChevronLeft,
  ChevronRight,
  Download,
  FileText
} from "lucide-react";
import goalImage from 'figma:asset/cec7519777cebfb331766056b82a58105a45f89a.png';
import backgroundResearchImage from 'figma:asset/9a840eb81680d99b10d6d1f9b388338c78e8b2db.png';
import quizDesignImage from 'figma:asset/50d5201a71b991810075f51dc16725f4fe0f4f34.png';
import summaryDesignImage from 'figma:asset/541d6ba8e993c47e0b74f5ad4168106c8d1e5c5f.png';
import prototypeRevisions1Image from 'figma:asset/e7b9dab51c0c9e1f83f34b5def1167651d3c4973.png';
import prototypeRevisions2Image from 'figma:asset/8d13f5084153f7dac870784a8bbad5172034991d.png';
import recommendationIdeationImage from 'figma:asset/182f12e1543d40ab29373ac06f5e77f5f34d2806.png';
import recommendationDesignImage from 'figma:asset/6b7a9fc89991724cc4d2b4ca90038747ac606809.png';
import windowNationStartImage from 'figma:asset/5c4d28f63bae1c4d7c880e731248189d49786fdf.png';
import windowNationQuoteImage from 'figma:asset/a00dc426357cd1120d9199158f645e730bb14f8d.png';
import windowNationCountImage from 'figma:asset/fddea78df0a02df2f7476da7bbabf5165d5e082c.png';
import windowNationBookingImage from 'figma:asset/cc7908f3232098e9a072a5710c85167a4d382d80.png';
import serviceMasterDashboard1Image from 'figma:asset/195d46171998161120b237523e5e60495e68e896.png';
import serviceMasterDashboard2Image from 'figma:asset/3e42e4f5fd5f75b2bc4324e96d5c088f1e95277a.png';
import crmQueueImage from 'figma:asset/7351b6cb04fa91d9dceab9ab2140997c8c391ceb.png';
import crmDetailsImage from 'figma:asset/7f93e9644a0aabff1860bf29e7abe8e14f259d8a.png';

export function CaseStudies() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentWindowNationIndex, setCurrentWindowNationIndex] = useState(0);
  const [currentServiceMasterIndex, setCurrentServiceMasterIndex] = useState(0);
  const [currentCRMIndex, setCurrentCRMIndex] = useState(0);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const herHeartImages = [
    {
      src: goalImage,
      title: "Project Goal",
      description: "Creating a Healthy Heart Score Tool to increase cardiac health awareness for African American teens"
    },
    {
      src: backgroundResearchImage,
      title: "Background Research",
      description: "Understanding teen motivations and conducting competitive analysis of existing health tools"
    },
    {
      src: quizDesignImage,
      title: "Quiz Design",
      description: "User feedback informed design decisions, from Buzzfeed-style engagement to teen-friendly language"
    },
    {
      src: summaryDesignImage,
      title: "Summary Design",
      description: "User feedback revealed need for clearer hierarchy, Band-Aid heart concept, and detailed y-axis values through participatory design sessions"
    },
    {
      src: prototypeRevisions1Image,
      title: "Prototype Revisions - Interface",
      description: "Design changes focused on clearer response hierarchy, more descriptive middle options, and engaging storytelling throughout the quiz"
    },
    {
      src: prototypeRevisions2Image,
      title: "Prototype Revisions - Visual",
      description: "Improved color contrast with darker backgrounds, vertical arrangement for clarity, prominent serving sizes, and emoji additions for engagement"
    },
    {
      src: recommendationIdeationImage,
      title: "Recommendation Page Ideation",
      description: "Design requirements and wireframe concepts focusing on positive reinforcement, anti-diet language, and encouraging healthcare provider conversations"
    },
    {
      src: recommendationDesignImage,
      title: "Recommendation Page Design",
      description: "Final mobile interface with slider feedback, positive messaging, dropdown menus for personalized recommendations, and encouragement for healthy behaviors"
    }
  ];

  const windowNationImages = [
    {
      src: windowNationStartImage,
      title: "Let's Get Started - Desktop",
      description: "Home screen where users will start the DCE experience. Actions: User types their initial contact form, agrees to be contacted, and then OR click the request a call link to fill out simple form. Features 'Ready for new windows or doors?' messaging with form fields for first name, last name, phone number, and email, plus 'START MY ESTIMATE' call-to-action."
    },
    {
      src: windowNationQuoteImage,
      title: "Which Home Would You Like a Quote - Desktop",
      description: "Where users can enter their address and indicate the property type. Actions: Enter Address, Click property type. Features progress indicator showing step 2 of 4, address input fields (street address, city, state, zip) and property type selection options including primary residence, rental property, second property, and investment property."
    },
    {
      src: windowNationCountImage,
      title: "Window Count - Desktop",
      description: "Where users can specify number of windows they want to be replaced. Actions: Click plus and minus buttons to add and remove windows OR Type in number of windows they want replaced. Note: Only window counts of 3 or higher qualify for an in-home consultation. Features house illustration and interactive counter interface."
    },
    {
      src: windowNationBookingImage,
      title: "Time and Date Booking - Desktop",
      description: "Final step where customers select their desired booking time within the next seven days. Actions: Customer toggles back and forth between the next 7-9 days to select their desired time and date. All homeowners/decision makers need to be able to attend. OR Customer can contact the call center to book a time if prompted with no available appointment slots."
    }
  ];

  const serviceMasterImages = [
    {
      src: serviceMasterDashboard1Image,
      title: "Comprehensive Analytics Dashboard - Current View",
      description: "Real-time operational analytics showing Revenue Trending, Sales Orders, and key performance indicators. Features revenue trends across business segments, damage claims tracking (0.06% rate), employee satisfaction scores (4.5/5), referral rates (97.5%), and at-risk employee monitoring. Includes AIE ranking (#15) and blocked trucks visualization for complete operational oversight."
    },
    {
      src: serviceMasterDashboard2Image,
      title: "Enhanced Analytics Dashboard - Redesigned View",
      description: "Streamlined dashboard interface with improved data visualization and user experience. Features monthly/yearly revenue trending with attribute filtering, move count analytics, referral rate tracking (97.4%), close rate monitoring (16.91%), and comprehensive employee performance metrics. Includes enhanced navigation with Marketing Dashboard, Daily Report, MES Dashboard, and other reporting tools for better operational efficiency."
    }
  ];

  const microsoftDynamicsImages = [
    {
      src: crmQueueImage,
      title: "2nd Look Queue - Customer Management Interface",
      description: "Microsoft Dynamics CRM integration showing the 2nd Look Queue for Lakelynn Health customer. Features comprehensive customer details including contact information, lender details with Foundation offering 24 months at 0% interest for $25,000 financing. Includes communication tracking, timeline management, and customer notification system with 'Customer And EDC Notified' status updates for streamlined loan processing workflow."
    },
    {
      src: crmDetailsImage,
      title: "Customer Details & Lender Management System",
      description: "Comprehensive CRM interface for Jillian Jones opportunity management showing Sales to Offer status with Robert Rodriguez as FOX representative in Atlanta, GA market. Features detailed customer information form, lender management system with multiple financing options (Credit/Greensky - $25,000 at 24 months 0% interest), timeline tracking, and integrated communication tools. Includes assigned rep system with Tymirra Smith and full address management capabilities."
    }
  ];

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % herHeartImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + herHeartImages.length) % herHeartImages.length);
  };

  const nextWindowNationImage = () => {
    setCurrentWindowNationIndex((prev) => (prev + 1) % windowNationImages.length);
  };

  const prevWindowNationImage = () => {
    setCurrentWindowNationIndex((prev) => (prev - 1 + windowNationImages.length) % windowNationImages.length);
  };

  const nextServiceMasterImage = () => {
    setCurrentServiceMasterIndex((prev) => (prev + 1) % serviceMasterImages.length);
  };

  const prevServiceMasterImage = () => {
    setCurrentServiceMasterIndex((prev) => (prev - 1 + serviceMasterImages.length) % serviceMasterImages.length);
  };

  const nextCRMImage = () => {
    setCurrentCRMIndex((prev) => (prev + 1) % microsoftDynamicsImages.length);
  };

  const prevCRMImage = () => {
    setCurrentCRMIndex((prev) => (prev - 1 + microsoftDynamicsImages.length) % microsoftDynamicsImages.length);
  };

  // PDF Generation Functions using browser print
  const generateCaseStudyPDF = async (caseStudy: any) => {
    setIsGeneratingPDF(true);
    
    try {
      // Get images for this specific case study
      let caseStudyImages = [];
      if (caseStudy.id === 'herheart') {
        caseStudyImages = herHeartImages;
      } else if (caseStudy.id === 'window-nation') {
        caseStudyImages = windowNationImages;
      } else if (caseStudy.id === 'servicemaster') {
        caseStudyImages = serviceMasterImages;
      } else if (caseStudy.id === 'microsoft-dynamics') {
        caseStudyImages = microsoftDynamicsImages;
      }

      const pdfContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${caseStudy.title} - Case Study</title>
    <style>
        @media print {
            body { margin: 0; padding: 20px; }
            .no-print { display: none; }
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #2a251f;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #8a5968;
        }
        .title {
            font-size: 28px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }
        .meta-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .meta-item {
            background: #f8f2ea;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            color: #8a5968;
            font-weight: 500;
        }
        .section {
            margin-bottom: 30px;
            break-inside: avoid;
        }
        .section-title {
            font-size: 22px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e8b485;
        }
        .description {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
            text-align: justify;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #fefdfb;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            break-inside: avoid;
        }
        .metric-value {
            font-size: 24px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 5px;
        }
        .metric-label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 3px;
        }
        .metric-improvement {
            font-size: 12px;
            color: #5a9498;
            font-weight: 600;
        }
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 20px 0;
        }
        .skill-tag {
            background: #e8b485;
            color: #2a251f;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 500;
        }
        .highlights-list {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        .highlights-list li {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .highlights-list li:before {
            content: "•";
            color: #8a5968;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        .image-gallery {
            margin: 30px 0;
        }
        .image-item {
            margin-bottom: 30px;
            page-break-inside: avoid;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            background: #fefdfb;
        }
        .image-item img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .image-title {
            font-size: 18px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 8px;
        }
        .image-description {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e8b485;
            font-size: 14px;
            color: #666;
        }
        .print-instruction {
            background: #e8b485;
            color: #2a251f;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="print-instruction no-print">
        <h3>Ready to Save as PDF</h3>
        <p>Use your browser's print function (Ctrl+P or Cmd+P) and select "Save as PDF" as the destination.</p>
        <button onclick="window.print()" style="background: #8a5968; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 10px;">Print to PDF</button>
        <button onclick="window.close()" style="background: #666; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 10px;">Close</button>
    </div>

    <div class="header">
        <div class="title">${caseStudy.title}</div>
        <div class="subtitle">UX Case Study by Tymirra Smith</div>
        <div class="meta-info">
            <div class="meta-item">${caseStudy.company}</div>
            <div class="meta-item">${caseStudy.period}</div>
            <div class="meta-item">${caseStudy.role}</div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">Project Overview</div>
        <div class="description">${caseStudy.description}</div>
    </div>

    <div class="section">
        <div class="section-title">Key Metrics & Impact</div>
        <div class="metrics-grid">
            ${caseStudy.metrics.map(metric => `
                <div class="metric-card">
                    <div class="metric-value">${metric.value}</div>
                    <div class="metric-label">${metric.label}</div>
                    <div class="metric-improvement">${metric.improvement}</div>
                </div>
            `).join('')}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Skills Applied</div>
        <div class="skills-container">
            ${caseStudy.skills.map(skill => `
                <div class="skill-tag">${skill}</div>
            `).join('')}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Key Highlights</div>
        <ul class="highlights-list">
            ${caseStudy.highlights.map(highlight => `
                <li>${highlight}</li>
            `).join('')}
        </ul>
    </div>

    ${caseStudyImages.length > 0 ? `
    <div class="section">
        <div class="section-title">Design Process & Visual Documentation</div>
        <div class="image-gallery">
            ${caseStudyImages.map(image => `
                <div class="image-item">
                    <img src="${image.src}" alt="${image.title}" />
                    <div class="image-title">${image.title}</div>
                    <div class="image-description">${image.description}</div>
                </div>
            `).join('')}
        </div>
    </div>
    ` : ''}

    <div class="footer">
        <p><strong>Tymirra Smith</strong> | Senior Product Designer<br>
        Portfolio: Available upon request | Email: tymirra@gmail.com<br>
        This case study contains proprietary business information and is intended for portfolio review purposes.</p>
    </div>

    <script>
        // Auto-trigger print dialog after a short delay
        setTimeout(() => {
            window.print();
        }, 1000);
    </script>
</body>
</html>`;

      // Open new window with print-optimized content
      const printWindow = window.open('', '_blank', 'width=800,height=600');
      if (printWindow) {
        printWindow.document.write(pdfContent);
        printWindow.document.close();
        printWindow.focus();
      } else {
        // Fallback: create downloadable HTML file
        const blob = new Blob([pdfContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${caseStudy.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_case_study_print.html`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        alert('PDF print window was blocked. A printable HTML file has been downloaded instead. Open it and use your browser\'s print function to save as PDF.');
      }

    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('There was an error generating the PDF. Please try again.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const generateAllCaseStudiesPDF = async () => {
    setIsGeneratingPDF(true);
    
    try {
      // Function to get images for each case study
      const getImagesForCaseStudy = (studyId: string) => {
        if (studyId === 'herheart') return herHeartImages;
        if (studyId === 'window-nation') return windowNationImages;
        if (studyId === 'servicemaster') return serviceMasterImages;
        if (studyId === 'microsoft-dynamics') return microsoftDynamicsImages;
        return [];
      };

      const allCaseStudiesContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tymirra Smith - Complete Case Studies Portfolio</title>
    <style>
        @media print {
            body { margin: 0; padding: 20px; }
            .no-print { display: none; }
            .case-study-separator { page-break-before: always; }
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #2a251f;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            background: white;
        }
        .cover-page {
            text-align: center;
            margin-bottom: 60px;
            padding: 60px 20px;
            border: 3px solid #8a5968;
            border-radius: 15px;
            background: linear-gradient(135deg, #fefdfb 0%, #f8f2ea 100%);
            break-inside: avoid;
        }
        .portfolio-title {
            font-size: 36px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 20px;
        }
        .portfolio-subtitle {
            font-size: 20px;
            color: #666;
            margin-bottom: 30px;
        }
        .portfolio-description {
            font-size: 16px;
            line-height: 1.8;
            max-width: 600px;
            margin: 0 auto 30px;
            text-align: justify;
        }
        .case-study-separator {
            text-align: center;
            margin: 40px 0;
            padding: 20px;
            background: #8a5968;
            color: white;
            border-radius: 10px;
        }
        .header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #8a5968;
        }
        .title {
            font-size: 28px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }
        .meta-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .meta-item {
            background: #f8f2ea;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            color: #8a5968;
            font-weight: 500;
        }
        .section {
            margin-bottom: 30px;
            break-inside: avoid;
        }
        .section-title {
            font-size: 22px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e8b485;
        }
        .description {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
            text-align: justify;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #fefdfb;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            break-inside: avoid;
        }
        .metric-value {
            font-size: 24px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 5px;
        }
        .metric-label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 3px;
        }
        .metric-improvement {
            font-size: 12px;
            color: #5a9498;
            font-weight: 600;
        }
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 20px 0;
        }
        .skill-tag {
            background: #e8b485;
            color: #2a251f;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 500;
        }
        .highlights-list {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        .highlights-list li {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .highlights-list li:before {
            content: "•";
            color: #8a5968;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        .image-gallery {
            margin: 30px 0;
        }
        .image-item {
            margin-bottom: 30px;
            page-break-inside: avoid;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            background: #fefdfb;
        }
        .image-item img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            max-height: 500px;
            object-fit: contain;
        }
        .image-title {
            font-size: 16px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 8px;
        }
        .image-description {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e8b485;
            font-size: 14px;
            color: #666;
        }
        .print-instruction {
            background: #e8b485;
            color: #2a251f;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="print-instruction no-print">
        <h3>Ready to Save Complete Portfolio as PDF</h3>
        <p>Use your browser's print function (Ctrl+P or Cmd+P) and select "Save as PDF" as the destination.</p>
        <button onclick="window.print()" style="background: #8a5968; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 10px;">Print to PDF</button>
        <button onclick="window.close()" style="background: #666; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 10px;">Close</button>
    </div>

    <div class="cover-page">
        <div class="portfolio-title">Complete Case Studies Portfolio</div>
        <div class="portfolio-subtitle">Tymirra Smith | Senior Product Designer</div>
        <div class="portfolio-description">
            This comprehensive portfolio showcases four major projects spanning enterprise software, healthcare innovation, 
            franchise optimization, and revenue-generating product design. Each case study demonstrates strategic thinking, 
            user-centered design methodology, and measurable business impact through thoughtful UX solutions.
        </div>
        <div class="meta-info">
            <div class="meta-item">4 Complete Case Studies</div>
            <div class="meta-item">$18.5M+ Combined Revenue Impact</div>
            <div class="meta-item">2,000+ Users Impacted</div>
        </div>
    </div>

    ${caseStudies.map((study, index) => {
      const studyImages = getImagesForCaseStudy(study.id);
      
      return `
        <div class="case-study-separator">
            <h2>Case Study ${index + 1}</h2>
            <h3>${study.title}</h3>
        </div>

        <div class="header">
            <div class="title">${study.title}</div>
            <div class="subtitle">UX Case Study by Tymirra Smith</div>
            <div class="meta-info">
                <div class="meta-item">${study.company}</div>
                <div class="meta-item">${study.period}</div>
                <div class="meta-item">${study.role}</div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">Project Overview</div>
            <div class="description">${study.description}</div>
        </div>

        <div class="section">
            <div class="section-title">Key Metrics & Impact</div>
            <div class="metrics-grid">
                ${study.metrics.map(metric => `
                    <div class="metric-card">
                        <div class="metric-value">${metric.value}</div>
                        <div class="metric-label">${metric.label}</div>
                        <div class="metric-improvement">${metric.improvement}</div>
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <div class="section-title">Skills Applied</div>
            <div class="skills-container">
                ${study.skills.map(skill => `
                    <div class="skill-tag">${skill}</div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <div class="section-title">Key Highlights</div>
            <ul class="highlights-list">
                ${study.highlights.map(highlight => `
                    <li>${highlight}</li>
                `).join('')}
            </ul>
        </div>

        ${studyImages.length > 0 ? `
        <div class="section">
            <div class="section-title">Design Process & Visual Documentation</div>
            <div class="image-gallery">
                ${studyImages.map(image => `
                    <div class="image-item">
                        <img src="${image.src}" alt="${image.title}" />
                        <div class="image-title">${image.title}</div>
                        <div class="image-description">${image.description}</div>
                    </div>
                `).join('')}
            </div>
        </div>
        ` : ''}
      `;
    }).join('')}

    <div class="footer">
        <p><strong>Tymirra Smith</strong> | Senior Product Designer<br>
        Portfolio: Available upon request | Email: tymirra@gmail.com<br>
        This portfolio contains proprietary business information and is intended for portfolio review purposes.<br>
        <em>Generated: ${new Date().toLocaleDateString()}</em></p>
    </div>

    <script>
        // Auto-trigger print dialog after a short delay
        setTimeout(() => {
            window.print();
        }, 1000);
    </script>
</body>
</html>`;

      // Open new window with print-optimized content
      const printWindow = window.open('', '_blank', 'width=800,height=600');
      if (printWindow) {
        printWindow.document.write(allCaseStudiesContent);
        printWindow.document.close();
        printWindow.focus();
      } else {
        // Fallback: create downloadable HTML file
        const blob = new Blob([allCaseStudiesContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'tymirra_smith_complete_portfolio_print.html';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        alert('PDF print window was blocked. A printable HTML file has been downloaded instead. Open it and use your browser\'s print function to save as PDF.');
      }

    } catch (error) {
      console.error('Error generating complete portfolio PDF:', error);
      alert('There was an error generating the portfolio. Please try again.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const caseStudies = [
    {
      id: "window-nation",
      title: "Window Nation: Digital Lead Generation",
      company: "Window Nation",
      role: "Senior Product Designer",
      period: "April 2024 - May 2025",
      description: "Led complete digital transformation of lead generation strategy, resulting in $3.5M revenue-generating online appointment booking platform.",
      image: windowNationStartImage,
      metrics: [
        { label: "Revenue Impact", value: "$3.5M", improvement: "since launch" },
        { label: "Lead Response", value: "60%", improvement: "faster" },
        { label: "Team Growth", value: "3 interns", improvement: "mentored" },
        { label: "Conversion", value: "35%", improvement: "increase" }
      ],
      skills: ["Team Leadership", "Enterprise UX", "Revenue Generation", "Cross-functional Collaboration"],
      highlights: [
        "Digital-first transformation",
        "Microsoft Dynamics integration",
        "Mentored 3 interns",
        "Real-time scheduling system"
      ],
      color: "teal",
      icon: <TrendingUp className="w-5 h-5" />
    },

    {
      id: "microsoft-dynamics",
      title: "Microsoft Dynamics CRM Integration",
      company: "Window Nation",
      role: "Senior Product Designer", 
      period: "April 2024 - May 2025",
      description: "Designed user experience for seamless CRM integration, reducing data entry time by 40% and improving sales team efficiency.",
      metrics: [
        { label: "Revenue Impact", value: "$3.5M", improvement: "since launch" },
        { label: "Lead Response", value: "60%", improvement: "faster" },
        { label: "Team Growth", value: "3 interns", improvement: "mentored" },
        { label: "Conversion", value: "35%", improvement: "increase" }
      ],
      skills: ["Team Leadership", "Enterprise UX", "Revenue Generation", "Cross-functional Collaboration"],
      highlights: [
        "Digital-first transformation",
        "Microsoft Dynamics integration",
        "Mentored 3 interns",
        "Real-time scheduling system"
      ],
      color: "teal",
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: "servicemaster",
      title: "ServiceMaster: Franchisee Optimization",
      company: "ServiceMaster Brands",
      role: "Senior Product Designer",
      period: "April 2024 - May 2025",
      description: "Designed user experience for seamless CRM integration, reducing data entry time by 40% and improving sales team efficiency.",
      metrics: [
        { label: "Data Entry", value: "40%", improvement: "reduction" },
        { label: "Data Accuracy", value: "99.2%", improvement: "with sync" },
        { label: "Team Trained", value: "15+", improvement: "sales reps" },
        { label: "Adoption Rate", value: "98%", improvement: "first month" }
      ],
      skills: ["Enterprise UX", "System Integration", "Workflow Design", "Change Management"],
      highlights: [
        "Automated task creation",
        "Real-time status updates",
        "Intelligent form pre-population",
        "Compliance & data integrity"
      ],
      color: "deep-purple",
      icon: <Users className="w-5 h-5" />
    },
    {
      id: "herheart",
      title: "HerHeart: Teen Cardiovascular Health Assessment",
      company: "Emory University",
      role: "Lead UX/UI Designer",
      period: "16 weeks (Jan – Apr 2024)",
      description: "Transformed clinical cardiovascular assessments into a gamified mobile experience for teenage girls, resulting in 103% increase in completion rates and measurable behavior change.",
      metrics: [
        { label: "Completion Rate", value: "75%", improvement: "+103%" },
        { label: "Revenue Generated", value: "$1,080", improvement: "in 7 days" },
        { label: "Score Improvement", value: "1.5 points", improvement: "avg increase" },
        { label: "Confidence Score", value: "4.3/5", improvement: "vs 3.1/5" },
        { label: "Follow-ups", value: "26/month", improvement: "vs 12/month" }
      ],
      skills: ["Healthcare UX", "Gamification", "Clinical Research", "User Testing", "Behavioral Design"],
      highlights: [
        "Featured in Emory News Center",
        "Published in Journal of Cardiovascular Imaging",
        "Duolingo-style micro-learning approach",
        "Badge system and streak rewards"
      ],
      color: "burgundy",
      icon: <Heart className="w-5 h-5" />
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      burgundy: "border-burgundy/20 bg-burgundy/5",
      coral: "border-coral/20 bg-coral/5",
      teal: "border-teal/20 bg-teal/5",
      "deep-purple": "border-deep-purple/20 bg-deep-purple/5",
      terracotta: "border-terracotta/20 bg-terracotta/5"
    };
    return colorMap[color] || "border-primary/20 bg-primary/5";
  };

  return (
    <div className="space-y-12">
      {/* PDF Download Section */}
      <Card className="border-2 border-primary/30 bg-primary/5">

      </Card>

      {/* Case Studies */}
      {caseStudies.map((study, index) => (
        <Card key={study.id} className={`${getColorClasses(study.color)} border-2 overflow-hidden`}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className={`bg-${study.color}/10 text-${study.color}`}>
                    {study.company}
                  </Badge>
                  {study.liveLink && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={study.liveLink} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Live
                      </a>
                    </Button>
                  )}
                </div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <span className={`p-2 rounded-lg bg-${study.color}/10 text-${study.color}`}>
                    {study.icon}
                  </span>
                  {study.title}
                </CardTitle>
                <p className="text-muted-foreground">
                  {study.role} • {study.period}
                </p>
              </div>
              <Button
                onClick={() => generateCaseStudyPDF(study)}
                disabled={isGeneratingPDF}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                {isGeneratingPDF ? (
                  <>
                    <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    <span className="hidden sm:inline">Generating...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-3 h-3" />
                    <span className="hidden sm:inline">Download PDF</span>
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <p className="text-lg leading-relaxed">{study.description}</p>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Key Metrics & Impact</h4>
                  <div className="grid grid-cols-2 gap-4">
                    {study.metrics.map((metric, idx) => (
                      <div key={idx} className="p-3 bg-background/60 rounded-lg">
                        <div className="text-2xl font-bold text-primary">{metric.value}</div>
                        <div className="text-sm text-muted-foreground">{metric.label}</div>
                        <div className="text-xs text-muted-foreground">{metric.improvement}</div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-semibold">Skills Applied</h4>
                  <div className="flex flex-wrap gap-2">
                    {study.skills.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-semibold">Key Highlights</h4>
                  <ul className="space-y-2">
                    {study.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="space-y-4">
                {study.id === "herheart" && (
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-burgundy/30 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-burgundy">Design Process Gallery</h4>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={prevImage}
                            className="h-8 w-8 p-0"
                          >
                            <ChevronLeft className="w-4 h-4" />
                          </Button>
                          <span className="text-xs text-muted-foreground">
                            {currentImageIndex + 1} / {herHeartImages.length}
                          </span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={nextImage}
                            className="h-8 w-8 p-0"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="w-full rounded-lg">
                        <img 
                          src={herHeartImages[currentImageIndex].src} 
                          alt={`HerHeart App ${herHeartImages[currentImageIndex].title}`}
                          className="w-full h-auto object-contain shadow-sm transition-opacity duration-300"
                          style={{ maxHeight: 'none', maxWidth: 'none' }}
                        />
                      </div>
                      
                      <div className="mt-3">
                        <h5 className="text-sm font-semibold text-burgundy mb-1">
                          {herHeartImages[currentImageIndex].title}
                        </h5>
                        <p className="text-sm text-muted-foreground">
                          {herHeartImages[currentImageIndex].description}
                        </p>
                      </div>
                      
                      {/* Dot indicators */}
                      <div className="flex justify-center gap-2 mt-4">
                        {herHeartImages.map((_, idx) => (
                          <button
                            key={idx}
                            onClick={() => setCurrentImageIndex(idx)}
                            className={`w-2 h-2 rounded-full transition-colors ${
                              idx === currentImageIndex 
                                ? 'bg-burgundy' 
                                : 'bg-burgundy/30 hover:bg-burgundy/50'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="bg-burgundy/5 border border-burgundy/20 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Award className="w-4 h-4 text-burgundy" />
                        <h4 className="font-semibold text-burgundy">Published Research</h4>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p>• Emory News Center (Feb 2025)</p>
                        <p>• Journal of Cardiovascular Imaging (May 2025)</p>
                        <p className="text-muted-foreground">First gamified clinical assessment tool to show measurable behavior change</p>
                      </div>
                    </div>
                  </div>
                )}

                {study.id === "window-nation" && (
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-teal/30 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-teal">User Journey Showcase</h4>
                        {windowNationImages.length > 1 && (
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={prevWindowNationImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronLeft className="w-4 h-4" />
                            </Button>
                            <span className="text-xs text-muted-foreground">
                              {currentWindowNationIndex + 1} / {windowNationImages.length}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={nextWindowNationImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                      
                      <div className="w-full rounded-lg">
                        <img 
                          src={windowNationImages[currentWindowNationIndex].src} 
                          alt={`Window Nation ${windowNationImages[currentWindowNationIndex].title}`}
                          className="w-full h-auto object-contain shadow-sm transition-opacity duration-300"
                          style={{ maxHeight: 'none', maxWidth: 'none' }}
                        />
                      </div>
                      
                      <div className="mt-3">
                        <h5 className="text-sm font-semibold text-teal mb-1">
                          {windowNationImages[currentWindowNationIndex].title}
                        </h5>
                        <p className="text-sm text-muted-foreground">
                          {windowNationImages[currentWindowNationIndex].description}
                        </p>
                      </div>
                      
                      {/* Dot indicators */}
                      {windowNationImages.length > 1 && (
                        <div className="flex justify-center gap-2 mt-4">
                          {windowNationImages.map((_, idx) => (
                            <button
                              key={idx}
                              onClick={() => setCurrentWindowNationIndex(idx)}
                              className={`w-2 h-2 rounded-full transition-colors ${
                                idx === currentWindowNationIndex 
                                  ? 'bg-teal' 
                                  : 'bg-teal/30 hover:bg-teal/50'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-teal/5 border border-teal/20 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingUp className="w-4 h-4 text-teal" />
                        <h4 className="font-semibold text-teal">Digital Transformation Impact</h4>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p>• Streamlined lead generation from phone-first to digital-first</p>
                        <p>• Microsoft Dynamics CRM integration for seamless data flow</p>
                        <p className="text-muted-foreground">Multi-step form design optimized for conversion and user experience</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {study.id === "microsoft-dynamics" && (
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-deep-purple/30 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-deep-purple">Microsoft Dynamics CRM Integration</h4>
                        {microsoftDynamicsImages.length > 1 && (
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={prevCRMImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronLeft className="w-4 h-4" />
                            </Button>
                            <span className="text-xs text-muted-foreground">
                              {currentCRMIndex + 1} / {microsoftDynamicsImages.length}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={nextCRMImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                      
                      <div className="w-full rounded-lg">
                        <img 
                          src={microsoftDynamicsImages[currentCRMIndex].src} 
                          alt={`Microsoft Dynamics CRM ${microsoftDynamicsImages[currentCRMIndex].title}`}
                          className="w-full h-auto object-contain shadow-sm transition-opacity duration-300"
                          style={{ maxHeight: 'none', maxWidth: 'none' }}
                        />
                      </div>
                      
                      <div className="mt-3">
                        <h5 className="text-sm font-semibold text-deep-purple mb-1">
                          {microsoftDynamicsImages[currentCRMIndex].title}
                        </h5>
                        <p className="text-sm text-muted-foreground">
                          {microsoftDynamicsImages[currentCRMIndex].description}
                        </p>
                      </div>
                      
                      {/* Dot indicators */}
                      {microsoftDynamicsImages.length > 1 && (
                        <div className="flex justify-center gap-2 mt-4">
                          {microsoftDynamicsImages.map((_, idx) => (
                            <button
                              key={idx}
                              onClick={() => setCurrentCRMIndex(idx)}
                              className={`w-2 h-2 rounded-full transition-colors ${
                                idx === currentCRMIndex 
                                  ? 'bg-deep-purple' 
                                  : 'bg-deep-purple/30 hover:bg-deep-purple/50'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-deep-purple/5 border border-deep-purple/20 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Users className="w-4 h-4 text-deep-purple" />
                        <h4 className="font-semibold text-deep-purple">CRM Integration Success</h4>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p>• Automated lead data synchronization and task creation</p>
                        <p>• Real-time updates and intelligent form pre-population</p>
                        <p className="text-muted-foreground">Seamless workflow integration for sales team efficiency</p>
                      </div>
                    </div>
                  </div>
                )}

                {study.id === "servicemaster" && (
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-terracotta/30 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-terracotta">Business Intelligence Dashboards</h4>
                        {serviceMasterImages.length > 1 && (
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={prevServiceMasterImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronLeft className="w-4 h-4" />
                            </Button>
                            <span className="text-xs text-muted-foreground">
                              {currentServiceMasterIndex + 1} / {serviceMasterImages.length}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={nextServiceMasterImage}
                              className="h-8 w-8 p-0"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                      
                      <div className="w-full rounded-lg">
                        <img 
                          src={serviceMasterImages[currentServiceMasterIndex].src} 
                          alt={`ServiceMaster ${serviceMasterImages[currentServiceMasterIndex].title}`}
                          className="w-full h-auto object-contain shadow-sm transition-opacity duration-300"
                          style={{ maxHeight: 'none', maxWidth: 'none' }}
                        />
                      </div>
                      
                      <div className="mt-3">
                        <h5 className="text-sm font-semibold text-terracotta mb-1">
                          {serviceMasterImages[currentServiceMasterIndex].title}
                        </h5>
                        <p className="text-sm text-muted-foreground">
                          {serviceMasterImages[currentServiceMasterIndex].description}
                        </p>
                      </div>
                      
                      {/* Dot indicators */}
                      {serviceMasterImages.length > 1 && (
                        <div className="flex justify-center gap-2 mt-4">
                          {serviceMasterImages.map((_, idx) => (
                            <button
                              key={idx}
                              onClick={() => setCurrentServiceMasterIndex(idx)}
                              className={`w-2 h-2 rounded-full transition-colors ${
                                idx === currentServiceMasterIndex 
                                  ? 'bg-terracotta' 
                                  : 'bg-terracotta/30 hover:bg-terracotta/50'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-terracotta/5 border border-terracotta/20 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <DollarSign className="w-4 h-4 text-terracotta" />
                        <h4 className="font-semibold text-terracotta">Multi-Brand Franchise Impact</h4>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p>• 12% lead conversion improvement across Terminix, AmeriSpec, and Merry Maids</p>
                        <p>• Comprehensive analytics for 2,000+ franchise locations</p>
                        <p className="text-muted-foreground">User research methodology adopted company-wide</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}