import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Heart, Brain, Lightbulb, Coffee } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-20 px-6">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="mb-4">About Me</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The person behind the pixels – my approach, philosophy, and what drives me
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="space-y-6">
            <Card className="border-l-4 border-l-burgundy">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-burgundy/10 rounded-lg">
                    <Heart className="w-5 h-5 text-burgundy" />
                  </div>
                  <h3 className="font-semibold">Design Philosophy</h3>
                </div>
                <p className="text-muted-foreground">
                  I believe great design happens when empathy meets strategy. Every user interaction 
                  should feel intentional, accessible, and—most importantly—solve a real problem. 
                  I don't just design interfaces; I design experiences that people actually want to use.
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-teal">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-teal/10 rounded-lg">
                    <Brain className="w-5 h-5 text-teal" />
                  </div>
                  <h3 className="font-semibold">My Approach</h3>
                </div>
                <p className="text-muted-foreground">
                  I'm a researcher at heart who designs with data, not assumptions. Before pixels 
                  hit the screen, I'm talking to users, analyzing behavior, and understanding the 
                  business context. My designs don't just look good—they perform measurably better.
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-coral">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-coral/10 rounded-lg">
                    <Lightbulb className="w-5 h-5 text-coral" />
                  </div>
                  <h3 className="font-semibold">What Drives Me</h3>
                </div>
                <p className="text-muted-foreground">
                  I'm energized by complex problems that require creative solutions. Whether it's 
                  getting teenagers to complete medical assessments or helping sales teams work 
                  more efficiently, I love finding the sweet spot between user needs and business goals.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-muted/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-terracotta/10 rounded-lg">
                    <Coffee className="w-5 h-5 text-terracotta" />
                  </div>
                  <h3 className="font-semibold">Beyond the Portfolio</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  When I'm not designing, you'll find me diving deep into behavioral psychology, 
                  experimenting with growth marketing tactics, or building side projects that solve 
                  problems I personally face (like ADHD planning tools).
                </p>
                <p className="text-muted-foreground">
                  I'm also passionate about mentoring emerging designers and believe in the power 
                  of diverse perspectives in creating inclusive design solutions.
                </p>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <h4 className="font-semibold">Core Competencies</h4>
              <div className="grid grid-cols-2 gap-3">
                <Badge variant="secondary" className="justify-center py-2">
                  User Research
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Product Strategy
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Healthcare UX
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Enterprise Design
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Growth Marketing
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Team Leadership
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  Data Analysis
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  A/B Testing
                </Badge>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Tools I Love</h4>
              <div className="text-sm text-muted-foreground space-y-2">
                <p><strong>Design:</strong> Figma, FigJam, Lottie, Adobe Creative Suite</p>
                <p><strong>Research:</strong> Maze, UserTesting, Miro, Google Analytics</p>
                <p><strong>Development:</strong> HTML/CSS, React basics, GitHub</p>
                <p><strong>Analytics:</strong> Mixpanel, Hotjar, Google Tag Manager</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}