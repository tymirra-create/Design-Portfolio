import { Button } from "./ui/button.tsx";
import { Badge } from "./ui/badge.tsx";
import { ImageWithFallback } from "./figma/ImageWithFallback.tsx";
import { ChevronDown, Mail, Download } from "lucide-react";
import profileImage from 'figma:asset/0256e7909e6e60b07c03b595482412ca75ab5a24.png';

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="pt-32 pb-20 px-6 bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="container mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="space-y-4">
                <Badge className="bg-primary/10 text-primary border-primary/20">
                  Senior Product Designer
                </Badge>
                <h1 className="text-4xl lg:text-5xl leading-tight">
                  I'm <span className="text-primary">Tymirra Smith</span>, and I turn user problems into business wins
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl">
                  Currently freelancing to help SAAS startups turn their ideas into revenue-generating products. 
                  Former Senior Product Designer at Window Nation and Lead UX Researcher at ServiceMaster Brands 
                  with a track record of creating solutions that drive measurable business impact.
                </p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <Badge variant="secondary" className="bg-burgundy/10 text-burgundy">
                  Healthcare UX
                </Badge>
                <Badge variant="secondary" className="bg-teal/10 text-teal">
                  Enterprise Design
                </Badge>
                <Badge variant="secondary" className="bg-coral/10 text-coral">
                  Growth Marketing
                </Badge>
                <Badge variant="secondary" className="bg-terracotta/10 text-terracotta">
                  Team Leadership
                </Badge>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                onClick={() => scrollToSection('case-studies')}
                className="inline-flex items-center gap-2"
              >
                View Case Studies
                <ChevronDown className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                asChild
              >
                <a href="mailto:tymirra@gmail.com?subject=Let's Connect">
                  <Mail className="w-4 h-4 mr-2" />
                  Let's Connect
                </a>
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="relative w-full max-w-md mx-auto">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-teal/20 rounded-2xl transform rotate-3"></div>
              <div className="relative bg-card rounded-2xl p-8 shadow-lg">
                <div className="w-64 h-64 mx-auto bg-muted rounded-full flex items-center justify-center">
                  <img 
                    src={profileImage}
                    alt="Tymirra Smith - Professional headshot in white t-shirt with warm smile in modern office setting"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <div className="mt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    📍 Atlanta, GA
                  </p>
                  <p className="text-sm text-muted-foreground">
                    🎓 UX Design & Research
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}