import { Card, CardContent, CardHeader, CardTitle } from "./ui/card.tsx";
import { Badge } from "./ui/badge.tsx";
import { TrendingUp, Users, Eye, Download } from "lucide-react";

export function AnalyticsDashboard() {
  const stats = [
    { label: "Total Visitors", value: "2,847", icon: <Users className="w-4 h-4" /> },
    { label: "Case Study Views", value: "1,234", icon: <Eye className="w-4 h-4" /> },
    { label: "Contact Form Submissions", value: "23", icon: <TrendingUp className="w-4 h-4" /> },
    { label: "PDF Downloads", value: "156", icon: <Download className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl mb-2">Portfolio Analytics Dashboard</h1>
          <p className="text-muted-foreground">Visitor insights and engagement metrics</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.label}
                </CardTitle>
                {stat.icon}
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">Today</Badge>
                  <span className="text-sm">15 new visitors viewed HerHeart case study</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">Yesterday</Badge>
                  <span className="text-sm">3 contact form submissions</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">2 days ago</Badge>
                  <span className="text-sm">12 PDF downloads</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Most Popular Content</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">HerHeart Case Study</span>
                  <Badge variant="outline">456 views</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">ADHD Weekly Reset</span>
                  <Badge variant="outline">342 views</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Window Nation Project</span>
                  <Badge variant="outline">289 views</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}