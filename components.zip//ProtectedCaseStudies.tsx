import { useState } from "react";
import { CaseStudies } from "./CaseStudies.tsx";
import { PasswordProtection } from "./PasswordProtection.tsx";
import { useAuth } from "./useAuth.tsx";
import { Card, CardContent } from "./ui/card.tsx";
import { Button } from "./ui/button.tsx";
import { Badge } from "./ui/badge.tsx";
import { Lock, Eye, Mail, Brain, Heart, Download } from "lucide-react";

export function ProtectedCaseStudies() {
  const { isAuthenticated, authenticate } = useAuth();
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  if (showPasswordForm) {
    return (
      <PasswordProtection
        title="Case Studies Access"
        subtitle="Enter password to view detailed project case studies"
        onAuthenticated={() => {
          authenticate();
          setShowPasswordForm(false);
        }}
      />
    );
  }

  if (!isAuthenticated) {
    return (
      <section id="case-studies" className="py-20 px-6 bg-muted/20">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="mb-4">Case Studies</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Deep dives into projects where I turned user problems into business wins
            </p>
          </div>

          <Card className="border-2 border-dashed border-primary/30 bg-primary/5">
            <CardContent className="p-12 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full mb-6">
                <Lock className="w-10 h-10 text-primary" />
              </div>
              
              <Badge variant="secondary" className="mb-4">
                Protected Content
              </Badge>
              
              <h3 className="text-2xl mb-4">Detailed Case Studies</h3>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                My comprehensive case studies include sensitive business metrics, detailed process documentation, 
                and proprietary design solutions. Access is provided to potential employers and collaborators.
              </p>

              <div className="space-y-4">
                <div className="grid md:grid-cols-5 gap-4 mb-8">
                  <div className="p-4 bg-background/50 rounded-lg">
                    <div className="w-8 h-8 bg-burgundy/10 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Heart className="w-4 h-4 text-burgundy" />
                    </div>
                    <h4 className="text-sm mb-1">HerHeart App</h4>
                    <p className="text-xs text-muted-foreground">+103% Completion</p>
                  </div>
                  <div className="p-4 bg-background/50 rounded-lg">
                    <div className="w-8 h-8 bg-coral/10 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <Brain className="w-4 h-4 text-coral" />
                    </div>
                    <h4 className="text-sm mb-1">ADHD Weekly Reset</h4>
                    <p className="text-xs text-muted-foreground">$1,080 in 7 days</p>
                  </div>
                  <div className="p-4 bg-background/50 rounded-lg">
                    <div className="w-8 h-8 bg-burgundy/10 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <span className="text-burgundy text-sm">WN</span>
                    </div>
                    <h4 className="text-sm mb-1">Window Nation</h4>
                    <p className="text-xs text-muted-foreground">$3.5M Revenue Impact</p>
                  </div>
                  <div className="p-4 bg-background/50 rounded-lg">
                    <div className="w-8 h-8 bg-deep-purple/10 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <span className="text-deep-purple text-sm">MS</span>
                    </div>
                    <h4 className="text-sm mb-1">Microsoft Dynamics</h4>
                    <p className="text-xs text-muted-foreground">40% Efficiency Gain</p>
                  </div>
                  <div className="p-4 bg-background/50 rounded-lg">
                    <div className="w-8 h-8 bg-teal/10 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <span className="text-teal text-sm">SM</span>
                    </div>
                    <h4 className="text-sm mb-1">ServiceMaster</h4>
                    <p className="text-xs text-muted-foreground">12% Conversion Boost</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    onClick={() => setShowPasswordForm(true)}
                    className="inline-flex items-center gap-2"
                    size="lg"
                  >
                    <Eye className="w-4 h-4" />
                    View Case Studies
                  </Button>
                  <Button 
                    variant="outline"
                    asChild
                    size="lg"
                  >
                    <a href="mailto:tymirra@gmail.com?subject=Case Studies Password Request&body=Hi Tymirra,%0D%0A%0D%0AI would like to request access to your detailed case studies. Could you please share the password?%0D%0A%0D%0AThank you!%0D%0A%0D%0AName:%0D%0ACompany:%0D%0ARole:">
                      <Mail className="w-4 h-4 mr-2" />
                      Request Access
                    </a>
                  </Button>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-dashed border-muted-foreground/30">
                <p className="text-xs text-muted-foreground">
                  Access includes detailed process documentation, user research findings, 
                  design iterations, and measurable business impact metrics.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section id="case-studies" className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="mb-4">Case Studies</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Deep dives into projects where I turned user problems into business wins
          </p>
        </div>
        <CaseStudies />
      </div>
    </section>
  );
}