import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { 
  Download, 
  FileText, 
  Heart, 
  TrendingUp, 
  Users, 
  DollarSign,
  CheckCircle,
  Target,
  Lightbulb,
  BarChart3,
  Clock,
  Award,
  Zap,
  ArrowLeft,
  Eye
} from "lucide-react";

interface CaseStudy {
  id: string;
  title: string;
  company: string;
  role: string;
  period: string;
  duration: string;
  teamSize: string;
  description: string;
  businessContext: string;
  challenge: string;
  approachMethodology: string;
  solution: string;
  designProcess: string[];
  keyInnovations: string[];
  results: string[];
  technicalConsiderations?: string;
  businessImpact?: string;
  metrics: Array<{
    label: string;
    value: string;
    improvement: string;
    trend: string;
  }>;
  skills: string[];
  color: string;
  icon: React.ReactNode;
}

export function PDFGenerator() {
  const [selectedStudy, setSelectedStudy] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const caseStudies: CaseStudy[] = [
    {
      id: "window-nation",
      title: "Window Nation: Digital Lead Generation Revolution",
      company: "Window Nation",
      role: "Senior Product Designer & Team Lead",
      period: "April 2024 - May 2025",
      duration: "13 months",
      teamSize: "Cross-functional team of 8 + 3 mentored interns",
      description: "Led the complete digital transformation of Window Nation's lead generation strategy, architecting and designing a comprehensive $3.5M revenue-generating online appointment booking platform that revolutionized how the company acquires and converts customers.",
      businessContext: "Window Nation, a leading home improvement company, was experiencing significant challenges with their traditional lead generation approach. The company was heavily reliant on outdated methods including cold calling, door-to-door sales, and fragmented digital touchpoints that weren't providing the conversion rates or customer experience needed to scale effectively. With increasing competition in the home improvement space and changing consumer expectations for digital-first experiences, Window Nation needed a fundamental transformation of their customer acquisition strategy.",
      challenge: "The existing system was a complex web of disconnected tools and manual processes. Sales teams were juggling between 5+ different platforms to manage a single lead, resulting in an average response time of 48+ hours and a lead-to-appointment conversion rate of just 12%. Customer experience was fragmented, with potential customers having to repeat information multiple times and experiencing inconsistent communication. The lack of real-time availability meant missed opportunities and frustrated customers. Additionally, there was no comprehensive data tracking to understand conversion bottlenecks or optimize the sales funnel.",
      approachMethodology: "I implemented a human-centered design approach combined with agile methodology and data-driven decision making. The project began with extensive stakeholder mapping and user research across three key user groups: potential customers, sales representatives, and sales managers. I conducted 25+ user interviews, 15+ stakeholder sessions, and analyzed 6 months of historical conversion data. The design process involved creating detailed user journey maps, identifying pain points through service blueprinting, and developing multiple prototype iterations tested with real users. I also established a mentorship program for 3 junior designers, creating a collaborative learning environment throughout the project.",
      solution: "I designed and led the development of an integrated digital-first lead generation ecosystem featuring: (1) A progressive web application with intelligent form design that reduced cognitive load and increased completion rates, (2) Real-time appointment scheduling with dynamic availability that integrated with technician calendars and geographic routing, (3) Automated lead qualification system that scored and routed leads based on customer needs and sales rep expertise, (4) Comprehensive CRM integration with Microsoft Dynamics that eliminated duplicate data entry, (5) Multi-channel follow-up automation including SMS, email, and phone call orchestration, and (6) Advanced analytics dashboard providing real-time insights into conversion funnels and performance metrics.",
      designProcess: [
        "Comprehensive stakeholder analysis and business requirements gathering across sales, marketing, and operations teams",
        "In-depth user research including customer interviews, sales rep shadowing, and competitive analysis of 12+ industry solutions",
        "Service design blueprinting to map the entire customer journey from initial interest to completed installation",
        "Information architecture development for complex scheduling and CRM integration requirements",
        "Wireframing and prototyping using Figma with interactive prototypes for user testing",
        "Iterative user testing with 40+ participants across different demographics and technical comfort levels",
        "Design system creation to ensure consistency across all digital touchpoints",
        "Collaborative design sessions with development team to ensure technical feasibility",
        "Change management planning and training material development for sales team adoption",
        "Post-launch optimization through continuous user feedback collection and A/B testing implementation"
      ],
      keyInnovations: [
        "Dynamic availability algorithm that optimized technician scheduling based on geographic proximity and skill specialization",
        "Progressive disclosure form design that reduced abandonment by 45% through psychological flow optimization",
        "Intelligent lead scoring system using machine learning to predict conversion probability",
        "Real-time notification system that alerted sales reps within 60 seconds of lead submission",
        "Automated follow-up sequences personalized based on customer interaction patterns and preferences",
        "Mobile-first responsive design ensuring seamless experience across all devices and contexts"
      ],
      results: [
        "Generated $3.5M in additional revenue within 8 months of launch through improved conversion rates",
        "Reduced average lead response time from 48+ hours to under 2 minutes through automation",
        "Increased lead-to-appointment conversion rate from 12% to 47% through optimized user experience",
        "Achieved 98% user satisfaction score based on post-appointment customer surveys",
        "Decreased cost per acquisition by 35% through more efficient lead qualification and routing",
        "Improved sales team productivity by 60% through elimination of manual data entry tasks",
        "Successfully mentored 3 junior designers who were promoted to senior roles during the project",
        "Established new design standards adopted across other Window Nation digital properties",
        "Received company-wide recognition as 'Innovation Project of the Year'",
        "Created scalable system architecture supporting 300% growth in lead volume without performance degradation"
      ],
      technicalConsiderations: "The solution required complex integration with existing systems including Microsoft Dynamics CRM, Calendly for scheduling, Twilio for SMS communications, and proprietary technician routing software. I worked closely with the development team to ensure API compatibility, data security compliance, and system performance optimization. The platform was built to handle 1000+ concurrent users and process up to 500 leads per day with 99.9% uptime reliability.",
      businessImpact: "Beyond the immediate revenue generation, this project transformed Window Nation's competitive positioning in the market. The company went from having one of the slowest response times in the industry to being recognized as a leader in customer experience. The data insights generated by the new system enabled strategic business decisions about market expansion, pricing optimization, and resource allocation. The success of this project led to Window Nation securing additional funding for market expansion and establishing the internal design team as a core business function.",
      metrics: [
        { label: "Revenue Generated", value: "$3.5M", improvement: "8 months", trend: "+285%" },
        { label: "Response Time", value: "<2 min", improvement: "vs 48+ hrs", trend: "96% faster" },
        { label: "Conversion Rate", value: "47%", improvement: "vs 12%", trend: "+292%" },
        { label: "User Satisfaction", value: "98%", improvement: "post-launch", trend: "+45%" },
        { label: "Cost Per Acquisition", value: "35%", improvement: "reduction", trend: "↓$450" },
        { label: "Team Productivity", value: "60%", improvement: "increase", trend: "+24 hrs/week" }
      ],
      skills: ["Product Strategy", "Team Leadership", "Enterprise UX", "Revenue Generation", "Cross-functional Collaboration", "Microsoft Dynamics Integration", "Lead Generation Optimization", "Mentorship & Development", "Change Management", "Data-Driven Design"],
      color: "teal",
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: "microsoft-dynamics",
      title: "Microsoft Dynamics CRM: Enterprise Integration Excellence",
      company: "Window Nation",
      role: "Senior Product Designer & Integration Specialist",
      period: "April 2024 - May 2025",
      duration: "Concurrent with lead generation project",
      teamSize: "Technical team of 6 + sales stakeholders",
      description: "Architected and designed the user experience for seamless Microsoft Dynamics CRM integration, eliminating data silos and reducing manual data entry time by 40% while improving sales team efficiency and data accuracy across the entire organization.",
      businessContext: "As part of the broader digital transformation at Window Nation, the sales organization was struggling with fragmented data management across multiple systems. Sales representatives were spending 3+ hours daily on administrative tasks, manually entering data into Microsoft Dynamics CRM, cross-referencing information between platforms, and dealing with data inconsistencies that led to customer service issues and lost opportunities. The lack of integrated workflows was creating bottlenecks that prevented the sales team from focusing on high-value customer interactions.",
      challenge: "The existing workflow required sales representatives to manually input customer information into Microsoft Dynamics CRM after collecting it from various touchpoints - website forms, phone calls, email inquiries, and in-person consultations. This process was not only time-consuming but error-prone, leading to duplicate records, incomplete customer profiles, and delayed follow-ups. Sales managers had limited visibility into team performance and pipeline health due to inconsistent data entry practices. The disconnect between the new lead generation platform and the CRM system threatened to create even more complexity rather than the intended streamlined experience.",
      approachMethodology: "I employed a systems thinking approach combined with enterprise UX principles and change management best practices. The project required deep collaboration with IT, sales operations, and Microsoft Dynamics specialists to understand technical constraints and possibilities. I conducted extensive workflow analysis, shadowing 15+ sales representatives during their daily routines, and mapping every touchpoint where data flowed between systems. The design process focused on creating invisible integration - where automation happened seamlessly without disrupting established sales workflows that were working well.",
      solution: "I designed a comprehensive integration solution that created a unified data ecosystem: (1) Automated data synchronization between the lead generation platform and Microsoft Dynamics with real-time bidirectional updates, (2) Intelligent form pre-population that eliminated redundant data entry by leveraging existing customer information, (3) Automated task creation and follow-up scheduling based on customer interaction patterns and sales stage progression, (4) Unified customer 360-degree view combining lead source, interaction history, appointment details, and sales progress, (5) Smart notification system alerting sales reps to high-priority actions without information overload, and (6) Customizable dashboard interfaces that adapted to different sales roles and experience levels.",
      designProcess: [
        "Comprehensive systems audit and data flow mapping across all existing platforms and touchpoints",
        "Extensive user research with sales representatives, managers, and administrative staff to understand current pain points",
        "Technical requirements gathering with IT team and Microsoft Dynamics consultants to identify integration possibilities",
        "Workflow redesign sessions with sales team to optimize processes while maintaining familiar interaction patterns",
        "Prototype development with realistic CRM data to test integration scenarios and edge cases",
        "Iterative testing with sales team using staged rollout approach to validate design decisions",
        "Training material development and change management planning to ensure smooth adoption",
        "Performance monitoring system design to track usage patterns and identify optimization opportunities",
        "Compliance and data security validation to meet enterprise requirements and regulations",
        "Documentation creation for ongoing maintenance and future system enhancements"
      ],
      keyInnovations: [
        "Contextual data intelligence that predicted required information based on customer type and interaction history",
        "Adaptive interface design that adjusted complexity based on user expertise and role requirements",
        "Automated duplicate detection and resolution system that maintained data integrity without user intervention",
        "Smart task prioritization algorithm that optimized sales rep focus based on conversion probability and timeline urgency",
        "Real-time collaboration features enabling seamless handoffs between sales team members",
        "Integrated communication hub connecting CRM data with email, SMS, and phone call logging"
      ],
      results: [
        "Reduced manual data entry time by 40% through intelligent automation and pre-population features",
        "Achieved 99.2% data accuracy with automated synchronization eliminating human error in data transfer",
        "Reached 98% user adoption rate within the first month through intuitive design and comprehensive training",
        "Improved sales team productivity with 2.5 additional hours daily available for customer-facing activities",
        "Increased pipeline visibility and forecasting accuracy by 45% through consistent data quality",
        "Enhanced customer satisfaction scores due to more personalized and informed sales interactions",
        "Established new enterprise integration standards adopted by other business units within Window Nation",
        "Reduced IT support tickets related to CRM issues by 70% through user-friendly design and automated processes",
        "Enabled advanced analytics and reporting capabilities previously impossible with fragmented data",
        "Created scalable integration framework supporting future system additions and modifications"
      ],
      technicalConsiderations: "The integration required sophisticated API management, real-time data synchronization protocols, and enterprise-grade security measures. I collaborated with the technical team to design error handling procedures, data backup systems, and performance optimization strategies. The solution included comprehensive audit trails, role-based access controls, and compliance features meeting enterprise security requirements while maintaining user experience quality.",
      businessImpact: "This integration project transformed Window Nation's sales operations from a manual, error-prone process to a streamlined, data-driven system. The improved data quality enabled better business intelligence, more accurate forecasting, and strategic decision-making capabilities. Sales managers gained unprecedented visibility into team performance and customer journey analytics, leading to more effective coaching and process improvements. The project established Window Nation as a leader in sales technology adoption within their industry.",
      metrics: [
        { label: "Data Entry Time", value: "40%", improvement: "reduction", trend: "↓2.4 hrs/day" },
        { label: "Data Accuracy", value: "99.2%", improvement: "achieved", trend: "+23%" },
        { label: "User Adoption", value: "98%", improvement: "first month", trend: "industry leading" },
        { label: "Sales Team Trained", value: "15+", improvement: "successful", trend: "100% retention" },
        { label: "Productivity Gain", value: "2.5 hrs", improvement: "daily/person", trend: "+30%" },
        { label: "System Integration", value: "5", improvement: "platforms", trend: "seamless" }
      ],
      skills: ["Enterprise UX", "System Integration", "Workflow Design", "Change Management", "Data Architecture", "Sales Process Optimization", "Microsoft Dynamics Expertise", "API Design", "User Training", "Performance Optimization"],
      color: "deep-purple",
      icon: <Users className="w-5 h-5" />
    },
    {
      id: "servicemaster",
      title: "ServiceMaster Brands: Multi-Brand Franchise Optimization",
      company: "ServiceMaster Brands",
      role: "Lead UX Researcher & Strategic Designer",
      period: "November 2021 - April 2024",
      duration: "2 years, 5 months",
      teamSize: "Research team of 4 across multiple brand portfolios",
      description: "Led comprehensive user research and design strategy across ServiceMaster's diverse brand portfolio, conducting extensive stakeholder research to design data-driven solutions that improved franchisee operations, increased lead conversion rates, and established unified UX standards across 2,000+ franchise locations.",
      businessContext: "ServiceMaster Brands operates one of the largest franchise systems in North America, with iconic brands including Terminix (pest control), AmeriSpec (home inspection), and Merry Maids (residential cleaning). Each brand served different markets with unique operational requirements, but they shared common challenges around franchisee support, lead generation effectiveness, and business intelligence. The company was experiencing increasing pressure from digital-native competitors and needed to modernize their franchise support systems while maintaining brand distinctiveness and operational flexibility.",
      challenge: "The three major brands under ServiceMaster's portfolio had evolved independently, creating inconsistent user experiences across 2,000+ franchise websites and operational platforms. Franchisees were struggling with poor lead conversion rates (averaging 8-15% across brands), limited access to actionable business intelligence, and disconnected operational tools that required multiple platform switches throughout their daily workflows. Each brand had different technology stacks, user interfaces, and data reporting methods, making it difficult for corporate teams to provide consistent support or identify best practices that could be shared across the portfolio. Additionally, the lack of standardized user research practices meant that product decisions were often made without deep understanding of franchisee needs or customer behaviors.",
      approachMethodology: "I implemented a comprehensive mixed-methods research approach combining quantitative data analysis with qualitative insights gathering. The methodology included large-scale stakeholder mapping across three distinct business models, longitudinal user research to understand seasonal variations in franchise operations, competitive analysis across home services industries, and collaborative design workshops with franchisees from different geographic markets and business maturity levels. I established a centralized research repository and standardized methodology that could scale across multiple brands while respecting their unique characteristics and market positioning.",
      solution: "I designed and led the implementation of a multi-faceted solution addressing franchisee operational needs: (1) Comprehensive business intelligence dashboards tailored to each brand's key performance indicators while maintaining visual consistency and shared interaction patterns, (2) Conversion-optimized lead generation forms using behavioral psychology principles and A/B testing methodologies proven across multiple franchise contexts, (3) Unified design system and UX guidelines that preserved brand identity while standardizing user experience patterns and reducing development complexity, (4) Franchisee training and support materials that improved technology adoption and business performance, (5) Cross-brand insights sharing platform that enabled successful franchisees to share strategies and learn from high-performing locations, and (6) Advanced analytics and reporting tools that provided corporate teams with unprecedented visibility into franchise performance and support needs.",
      designProcess: [
        "Comprehensive stakeholder ecosystem mapping across three distinct brand portfolios and franchise business models",
        "Large-scale franchisee interview program including 50+ in-depth sessions across different markets, demographics, and performance levels",
        "Quantitative data analysis of 2+ years of franchise performance data, website analytics, and customer behavior patterns",
        "Competitive intelligence gathering and analysis of 15+ direct and indirect competitors across home services industries",
        "Customer journey mapping for each brand's unique service delivery model and typical customer interaction patterns",
        "Collaborative design workshops with high-performing franchisees to identify success factors and scalable best practices",
        "Prototype development and testing with representative franchisee groups across different technology comfort levels",
        "Implementation planning with brand managers and technology teams to ensure seamless rollout across diverse systems",
        "Training program development and delivery to support franchisee adoption of new tools and processes",
        "Continuous optimization through post-launch research, usage analytics, and franchisee feedback collection systems"
      ],
      keyInnovations: [
        "Cross-brand insights engine that identified successful strategies from one brand and adapted them for others",
        "Predictive analytics dashboard that helped franchisees identify optimal marketing timing and resource allocation",
        "Modular design system that maintained brand distinctiveness while achieving operational efficiency and consistency",
        "Franchisee success scoring algorithm that enabled targeted support and mentorship program matching",
        "Automated competitive monitoring system that alerted franchisees to local market opportunities and threats",
        "Mobile-optimized interfaces recognizing that many franchisees managed operations while in the field"
      ],
      results: [
        "Achieved 12% average increase in lead conversion rates across all three brands through optimized form design and user experience improvements",
        "Successfully implemented unified UX standards across 2,000+ franchise websites while maintaining brand distinctiveness",
        "Created comprehensive business intelligence dashboards serving franchisees across Terminix, AmeriSpec, and Merry Maids",
        "Established new user research methodology and standards adopted company-wide across all ServiceMaster brands",
        "Significantly influenced strategic product roadmap decisions and resource allocation across multiple business units",
        "Improved franchisee satisfaction scores by 28% through better operational tools and support resources",
        "Reduced franchisee onboarding time by 35% through streamlined interfaces and improved training materials",
        "Generated estimated $15M+ in additional revenue across the franchise system through conversion improvements",
        "Created scalable research and design processes that continue to inform new product development",
        "Received industry recognition for innovative approach to multi-brand franchise system optimization"
      ],
      technicalConsiderations: "The project required integration across multiple technology platforms, content management systems, and data warehouses. I worked with technical teams to ensure that design solutions were feasible within existing infrastructure constraints while planning for future technology modernization. The solution included robust analytics tracking, API integrations for data sharing, and responsive design principles that performed well across the diverse technology environments used by franchisees.",
      businessImpact: "This comprehensive research and design initiative transformed how ServiceMaster approaches franchisee support and product development. The insights generated continue to influence strategic business decisions, technology investments, and franchise support programs. The standardized research methodology has been adopted across additional ServiceMaster brands, and the cross-brand insights sharing approach has become a key competitive advantage in franchise recruitment and retention.",
      metrics: [
        { label: "Conversion Rate Boost", value: "12%", improvement: "average across brands", trend: "+$15M revenue" },
        { label: "Franchise Implementation", value: "2,000+", improvement: "websites updated", trend: "100% coverage" },
        { label: "Brand Portfolio", value: "3", improvement: "major brands", trend: "unified standards" },
        { label: "Research Scale", value: "50+", improvement: "stakeholder interviews", trend: "comprehensive" },
        { label: "Franchisee Satisfaction", value: "28%", improvement: "increase", trend: "industry leading" },
        { label: "Onboarding Efficiency", value: "35%", improvement: "time reduction", trend: "faster ROI" }
      ],
      skills: ["User Research", "Data Analysis", "Business Intelligence", "Multi-brand Strategy", "Conversion Optimization", "Stakeholder Management", "Franchise Systems", "Cross-functional Leadership", "Strategic Design", "Performance Analytics"],
      color: "terracotta",
      icon: <DollarSign className="w-5 h-5" />
    },
    {
      id: "herheart",
      title: "HerHeart: Cardiovascular Health Gamification for Teens",
      company: "Emory University School of Medicine",
      role: "Lead UX/UI Designer & Clinical Research Collaborator",
      period: "January 2023 - April 2023",
      duration: "16 weeks intensive research collaboration",
      teamSize: "Multidisciplinary team of 6 (design, clinical, research)",
      description: "Collaborated with Emory University's cardiology department to transform traditional clinical cardiovascular health assessments into an engaging, gamified mobile experience for teenage girls, resulting in a 103% increase in completion rates and measurable improvements in health awareness and behavior change.",
      businessContext: "Cardiovascular disease is the leading cause of death globally, with risk factors often developing during adolescence. However, traditional clinical assessment approaches for teenage cardiovascular health have historically shown poor engagement rates, particularly among teenage girls who face unique physiological and psychosocial factors affecting heart health. Emory University's cardiology research department was struggling with low participation rates in their longitudinal study of teenage cardiovascular health, with only 37% of participants completing assessments and even fewer engaging with educational content or follow-up recommendations.",
      challenge: "The existing clinical cardiovascular health assessment was a lengthy, medical-focused questionnaire that felt intimidating and irrelevant to teenage participants. The assessment took 15-20 minutes to complete, used clinical terminology that was difficult for teenagers to understand, provided little immediate value or feedback, and offered no motivation for continued engagement or behavior change. Research participation rates were critically low, making it difficult to gather the longitudinal data needed for meaningful clinical insights. Additionally, the assessment provided no educational value to participants, missing an opportunity to improve health literacy and promote positive cardiovascular health behaviors during a critical developmental period.",
      approachMethodology: "I employed a human-centered design approach specifically adapted for adolescent health contexts, incorporating principles from behavioral psychology, gamification theory, and clinical research requirements. The methodology included extensive literature review of successful health behavior change interventions, direct collaboration with Emory cardiologists to ensure clinical accuracy, focus groups with teenage girls to understand motivations and barriers, iterative prototype testing with target demographic participants, and validation studies measuring both engagement metrics and health knowledge retention. The approach required balancing clinical rigor with teenage user experience expectations and preferences.",
      solution: "I designed a comprehensive mobile-first health assessment experience that transformed clinical evaluation into an engaging, educational journey: (1) Gamified assessment structure inspired by successful educational platforms like Duolingo, with progressive levels, achievement badges, and completion rewards, (2) Interactive micro-learning modules that provided immediate health insights and actionable advice based on individual responses, (3) Personalized health dashboard with visual progress tracking and goal-setting capabilities, (4) Social features enabling anonymous peer comparison and community support while maintaining privacy, (5) Push notification system with encouraging messages and health tips delivered at optimal engagement times, and (6) Integration with wearable devices and health apps to provide holistic health tracking beyond the clinical assessment.",
      designProcess: [
        "Extensive literature review of adolescent health behavior research and successful gamification implementations in healthcare",
        "Collaborative requirements gathering with Emory cardiology team to understand clinical assessment objectives and constraints",
        "Focus group sessions with 15+ teenage girls to understand health perceptions, technology preferences, and motivation factors",
        "Competitive analysis of successful health and educational apps targeting teenage demographics",
        "User persona development specific to teenage girls with varying health awareness and engagement levels",
        "Iterative wireframing and prototyping with continuous feedback from both clinical team and target users",
        "Clinical validation testing to ensure health information accuracy and appropriateness for teenage audience",
        "Behavioral testing and user journey optimization through multiple rounds of prototype testing",
        "Implementation of privacy and consent protocols appropriate for adolescent research participants",
        "Post-launch longitudinal study design to measure engagement sustainability and health behavior changes"
      ],
      keyInnovations: [
        "Adaptive questioning system that adjusted clinical assessment complexity based on individual health literacy levels",
        "Micro-learning approach that delivered health education in 30-second digestible segments integrated throughout the assessment",
        "Achievement system specifically designed around cardiovascular health milestones and knowledge acquisition",
        "Privacy-first social features that enabled peer support while maintaining complete anonymity and HIPAA compliance",
        "Behavioral nudge system using positive psychology principles to encourage continued engagement without pressure",
        "Visual progress tracking that made abstract health concepts concrete and personally relevant for teenage users"
      ],
      results: [
        "Increased assessment completion rates from 37% to 75%, representing a 103% improvement in research participation",
        "Extended average engagement time from 2 minutes 15 seconds to 4 minutes 50 seconds through improved user experience",
        "Improved user confidence in cardiovascular health knowledge from 3.1/5 to 4.3/5 based on pre/post assessment surveys",
        "Generated 26 monthly follow-up interactions versus previous 12/month, indicating sustained engagement",
        "Achieved 89% user satisfaction rating and 92% likelihood-to-recommend score among participants",
        "Featured prominently in Emory University News Center as an example of innovative clinical research methodology",
        "Research findings published in peer-reviewed Journal of Cardiovascular Imaging with focus on design methodology",
        "Served as model for subsequent Emory digital health initiatives across multiple medical departments",
        "Created reusable design framework for health gamification that has been adapted for other clinical research projects",
        "Demonstrated measurable behavior change with 67% of participants reporting increased cardiovascular health awareness"
      ],
      technicalConsiderations: "All health information and assessment content was rigorously reviewed by Emory cardiologists and validated against current American Heart Association guidelines. The gamification elements were designed to enhance rather than compromise clinical accuracy, with built-in safeguards ensuring that engagement mechanics never contradicted evidence-based health recommendations. The project received IRB approval and included comprehensive consent processes appropriate for adolescent research participation.",
      businessImpact: "This project contributed to the growing body of research on digital health interventions for adolescents and demonstrated the potential for design-led approaches to improve clinical research outcomes. The methodology and results have been shared at multiple academic conferences and have influenced subsequent research projects at Emory and other academic medical centers. The work represents a successful model for designer-clinician collaboration in health research contexts.",
      metrics: [
        { label: "Completion Rate", value: "103%", improvement: "increase (37%→75%)", trend: "sustained" },
        { label: "Engagement Time", value: "2.2x", improvement: "longer sessions", trend: "quality focus" },
        { label: "Health Confidence", value: "4.3/5", improvement: "vs 3.1/5 baseline", trend: "+39%" },
        { label: "Follow-up Rate", value: "117%", improvement: "increase", trend: "sustained engagement" },
        { label: "User Satisfaction", value: "89%", improvement: "highly satisfied", trend: "92% recommend" },
        { label: "Behavior Change", value: "67%", improvement: "increased awareness", trend: "measurable impact" }
      ],
      skills: ["Healthcare UX", "Gamification Design", "Clinical Research", "Adolescent Psychology", "User Testing", "Behavioral Design", "Mobile-First Design", "Academic Collaboration", "Privacy Compliance", "Health Literacy"],
      color: "burgundy",
      icon: <Heart className="w-5 h-5" />
    }
  ];

  const generatePDF = async (study: CaseStudy) => {
    setIsGenerating(true);
    
    try {
      // Create PDF content as HTML string
      const pdfContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${study.title} - Case Study</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #2a251f;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #8a5968;
        }
        .title {
            font-size: 28px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }
        .meta-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .meta-item {
            background: #f8f2ea;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            color: #8a5968;
            font-weight: 500;
        }
        .section {
            margin-bottom: 30px;
        }
        .section-title {
            font-size: 22px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e8b485;
        }
        .subsection-title {
            font-size: 18px;
            font-weight: 600;
            color: #2a251f;
            margin: 20px 0 10px 0;
        }
        .description {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
            text-align: justify;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #fefdfb;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
        }
        .metric-value {
            font-size: 24px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 5px;
        }
        .metric-label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 3px;
        }
        .metric-improvement {
            font-size: 12px;
            color: #666;
            margin-bottom: 3px;
        }
        .metric-trend {
            font-size: 12px;
            color: #5a9498;
            font-weight: 600;
        }
        .list-item {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .list-item:before {
            content: "•";
            color: #8a5968;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        .process-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .process-item {
            background: #f8f2ea;
            border-radius: 8px;
            padding: 15px;
            border-left: 4px solid #8a5968;
        }
        .process-number {
            background: #8a5968;
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            margin-right: 10px;
        }
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 20px 0;
        }
        .skill-tag {
            background: #e8b485;
            color: #2a251f;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 500;
        }
        .page-break {
            page-break-before: always;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e8b485;
            font-size: 14px;
            color: #666;
        }
        @media print {
            body { margin: 0; padding: 20px; }
            .page-break { page-break-before: always; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">${study.title}</div>
        <div class="subtitle">UX Case Study by Tymirra Smith</div>
        <div class="meta-info">
            <div class="meta-item">${study.company}</div>
            <div class="meta-item">${study.period}</div>
            <div class="meta-item">${study.duration}</div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">Project Overview</div>
        <div class="description">${study.description}</div>
        <div class="subsection-title">Role & Team</div>
        <div class="description"><strong>Role:</strong> ${study.role}<br>
        <strong>Team Size:</strong> ${study.teamSize}</div>
    </div>

    <div class="section">
        <div class="section-title">Business Context</div>
        <div class="description">${study.businessContext}</div>
    </div>

    <div class="section">
        <div class="section-title">The Challenge</div>
        <div class="description">${study.challenge}</div>
    </div>

    <div class="section">
        <div class="section-title">Approach & Methodology</div>
        <div class="description">${study.approachMethodology}</div>
    </div>

    <div class="page-break"></div>

    <div class="section">
        <div class="section-title">The Solution</div>
        <div class="description">${study.solution}</div>
    </div>

    <div class="section">
        <div class="section-title">Design Process</div>
        <div class="process-grid">
            ${study.designProcess.map((step, index) => `
                <div class="process-item">
                    <span class="process-number">${index + 1}</span>
                    ${step}
                </div>
            `).join('')}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Key Innovations</div>
        ${study.keyInnovations.map(innovation => `
            <div class="list-item">${innovation}</div>
        `).join('')}
    </div>

    <div class="page-break"></div>

    <div class="section">
        <div class="section-title">Key Metrics & Impact</div>
        <div class="metrics-grid">
            ${study.metrics.map(metric => `
                <div class="metric-card">
                    <div class="metric-value">${metric.value}</div>
                    <div class="metric-label">${metric.label}</div>
                    <div class="metric-improvement">${metric.improvement}</div>
                    <div class="metric-trend">${metric.trend}</div>
                </div>
            `).join('')}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Results & Outcomes</div>
        ${study.results.map(result => `
            <div class="list-item">${result}</div>
        `).join('')}
    </div>

    ${study.technicalConsiderations ? `
    <div class="section">
        <div class="section-title">Technical Considerations</div>
        <div class="description">${study.technicalConsiderations}</div>
    </div>
    ` : ''}

    ${study.businessImpact ? `
    <div class="section">
        <div class="section-title">Business Impact</div>
        <div class="description">${study.businessImpact}</div>
    </div>
    ` : ''}

    <div class="section">
        <div class="section-title">Skills & Technologies</div>
        <div class="skills-container">
            ${study.skills.map(skill => `
                <div class="skill-tag">${skill}</div>
            `).join('')}
        </div>
    </div>

    <div class="footer">
        <p><strong>Tymirra Smith</strong> | Senior Product Designer<br>
        Portfolio: Available upon request | Email: tymirra@gmail.com<br>
        This case study contains proprietary business information and is intended for portfolio review purposes.</p>
    </div>
</body>
</html>
      `;

      // Create a new window and write the content
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(pdfContent);
        printWindow.document.close();
        
        // Trigger print dialog
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 250);
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateAllCaseStudiesPDF = async () => {
    setIsGenerating(true);
    
    try {
      const allCaseStudiesContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tymirra Smith - Complete Case Studies Portfolio</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #2a251f;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            background: white;
        }
        .cover-page {
            text-align: center;
            margin-bottom: 60px;
            padding: 60px 20px;
            border: 3px solid #8a5968;
            border-radius: 15px;
            background: linear-gradient(135deg, #fefdfb 0%, #f8f2ea 100%);
        }
        .portfolio-title {
            font-size: 36px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 20px;
        }
        .portfolio-subtitle {
            font-size: 20px;
            color: #666;
            margin-bottom: 30px;
        }
        .portfolio-description {
            font-size: 16px;
            line-height: 1.8;
            max-width: 600px;
            margin: 0 auto 30px;
            text-align: justify;
        }
        .case-study-separator {
            page-break-before: always;
            text-align: center;
            margin: 40px 0;
            padding: 20px;
            background: #8a5968;
            color: white;
            border-radius: 10px;
        }
        .header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #8a5968;
        }
        .title {
            font-size: 28px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 10px;
        }
        .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }
        .meta-info {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .meta-item {
            background: #f8f2ea;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            color: #8a5968;
            font-weight: 500;
        }
        .section {
            margin-bottom: 30px;
        }
        .section-title {
            font-size: 22px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e8b485;
        }
        .subsection-title {
            font-size: 18px;
            font-weight: 600;
            color: #2a251f;
            margin: 20px 0 10px 0;
        }
        .description {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
            text-align: justify;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #fefdfb;
            border: 2px solid #e8b485;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
        }
        .metric-value {
            font-size: 24px;
            font-weight: 700;
            color: #8a5968;
            margin-bottom: 5px;
        }
        .metric-label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 3px;
        }
        .metric-improvement {
            font-size: 12px;
            color: #666;
            margin-bottom: 3px;
        }
        .metric-trend {
            font-size: 12px;
            color: #5a9498;
            font-weight: 600;
        }
        .list-item {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .list-item:before {
            content: "•";
            color: #8a5968;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        .process-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .process-item {
            background: #f8f2ea;
            border-radius: 8px;
            padding: 15px;
            border-left: 4px solid #8a5968;
        }
        .process-number {
            background: #8a5968;
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            margin-right: 10px;
        }
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 20px 0;
        }
        .skill-tag {
            background: #e8b485;
            color: #2a251f;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 500;
        }
        .page-break {
            page-break-before: always;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e8b485;
            font-size: 14px;
            color: #666;
        }
        .toc {
            margin: 40px 0;
            padding: 30px;
            background: #f8f2ea;
            border-radius: 10px;
        }
        .toc-title {
            font-size: 24px;
            font-weight: 600;
            color: #8a5968;
            margin-bottom: 20px;
            text-align: center;
        }
        .toc-item {
            padding: 10px 0;
            border-bottom: 1px solid #e8b485;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .toc-item:last-child {
            border-bottom: none;
        }
        .toc-project {
            font-weight: 600;
            color: #8a5968;
        }
        .toc-company {
            color: #666;
            font-size: 14px;
        }
        @media print {
            body { margin: 0; padding: 20px; }
            .page-break { page-break-before: always; }
        }
    </style>
</head>
<body>
    <div class="cover-page">
        <div class="portfolio-title">Complete Case Studies Portfolio</div>
        <div class="portfolio-subtitle">Tymirra Smith | Senior Product Designer</div>
        <div class="portfolio-description">
            This comprehensive portfolio showcases four major projects spanning enterprise software, healthcare innovation, 
            franchise optimization, and revenue-generating product design. Each case study demonstrates strategic thinking, 
            user-centered design methodology, and measurable business impact through thoughtful UX solutions.
        </div>
        <div class="meta-info">
            <div class="meta-item">4 Complete Case Studies</div>
            <div class="meta-item">$18.5M+ Combined Revenue Impact</div>
            <div class="meta-item">2,000+ Users Impacted</div>
        </div>
    </div>

    <div class="toc">
        <div class="toc-title">Table of Contents</div>
        ${caseStudies.map((study, index) => `
            <div class="toc-item">
                <div>
                    <div class="toc-project">${index + 1}. ${study.title}</div>
                    <div class="toc-company">${study.company} • ${study.period}</div>
                </div>
            </div>
        `).join('')}
    </div>

    ${caseStudies.map((study, index) => `
        <div class="case-study-separator">
            <h2>Case Study ${index + 1}</h2>
            <h3>${study.title}</h3>
        </div>

        <div class="header">
            <div class="title">${study.title}</div>
            <div class="subtitle">UX Case Study by Tymirra Smith</div>
            <div class="meta-info">
                <div class="meta-item">${study.company}</div>
                <div class="meta-item">${study.period}</div>
                <div class="meta-item">${study.duration}</div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">Project Overview</div>
            <div class="description">${study.description}</div>
            <div class="subsection-title">Role & Team</div>
            <div class="description"><strong>Role:</strong> ${study.role}<br>
            <strong>Team Size:</strong> ${study.teamSize}</div>
        </div>

        <div class="section">
            <div class="section-title">Business Context</div>
            <div class="description">${study.businessContext}</div>
        </div>

        <div class="section">
            <div class="section-title">The Challenge</div>
            <div class="description">${study.challenge}</div>
        </div>

        <div class="section">
            <div class="section-title">Approach & Methodology</div>
            <div class="description">${study.approachMethodology}</div>
        </div>

        <div class="page-break"></div>

        <div class="section">
            <div class="section-title">The Solution</div>
            <div class="description">${study.solution}</div>
        </div>

        <div class="section">
            <div class="section-title">Design Process</div>
            <div class="process-grid">
                ${study.designProcess.map((step, stepIndex) => `
                    <div class="process-item">
                        <span class="process-number">${stepIndex + 1}</span>
                        ${step}
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <div class="section-title">Key Innovations</div>
            ${study.keyInnovations.map(innovation => `
                <div class="list-item">${innovation}</div>
            `).join('')}
        </div>

        <div class="page-break"></div>

        <div class="section">
            <div class="section-title">Key Metrics & Impact</div>
            <div class="metrics-grid">
                ${study.metrics.map(metric => `
                    <div class="metric-card">
                        <div class="metric-value">${metric.value}</div>
                        <div class="metric-label">${metric.label}</div>
                        <div class="metric-improvement">${metric.improvement}</div>
                        <div class="metric-trend">${metric.trend}</div>
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <div class="section-title">Results & Outcomes</div>
            ${study.results.map(result => `
                <div class="list-item">${result}</div>
            `).join('')}
        </div>

        ${study.technicalConsiderations ? `
        <div class="section">
            <div class="section-title">Technical Considerations</div>
            <div class="description">${study.technicalConsiderations}</div>
        </div>
        ` : ''}

        ${study.businessImpact ? `
        <div class="section">
            <div class="section-title">Business Impact</div>
            <div class="description">${study.businessImpact}</div>
        </div>
        ` : ''}

        <div class="section">
            <div class="section-title">Skills & Technologies</div>
            <div class="skills-container">
                ${study.skills.map(skill => `
                    <div class="skill-tag">${skill}</div>
                `).join('')}
            </div>
        </div>

        ${index < caseStudies.length - 1 ? '<div class="page-break"></div>' : ''}
    `).join('')}

    <div class="footer">
        <p><strong>Tymirra Smith</strong> | Senior Product Designer<br>
        Portfolio: Available upon request | Email: tymirra@gmail.com<br>
        This portfolio contains proprietary business information and is intended for portfolio review purposes.<br>
        <em>Generated: ${new Date().toLocaleDateString()}</em></p>
    </div>
</body>
</html>
      `;

      // Create a new window and write the content
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(allCaseStudiesContent);
        printWindow.document.close();
        
        // Trigger print dialog
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 250);
      }
    } catch (error) {
      console.error('Error generating complete portfolio PDF:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  if (selectedStudy) {
    const study = caseStudies.find(s => s.id === selectedStudy);
    if (!study) return null;

    return (
      <div className="min-h-screen bg-background p-6">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-8">
            <Button 
              onClick={() => setSelectedStudy(null)}
              variant="outline"
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to All Case Studies
            </Button>
            
            <Card className="border-2 border-primary/20">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-2xl flex items-center gap-3">
                    <span className="p-3 rounded-lg bg-primary/10 text-primary">
                      {study.icon}
                    </span>
                    {study.title}
                  </CardTitle>
                  <Badge variant="secondary" className="bg-primary/10 text-primary">
                    {study.company}
                  </Badge>
                </div>
                <p className="text-muted-foreground">{study.description}</p>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <Clock className="w-5 h-5 text-primary mb-2" />
                      <div className="font-medium">{study.duration}</div>
                      <div className="text-sm text-muted-foreground">Duration</div>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <Users className="w-5 h-5 text-primary mb-2" />
                      <div className="font-medium">{study.teamSize}</div>
                      <div className="text-sm text-muted-foreground">Team Size</div>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <Target className="w-5 h-5 text-primary mb-2" />
                      <div className="font-medium">{study.role}</div>
                      <div className="text-sm text-muted-foreground">Role</div>
                    </div>
                  </div>

                  <Separator />

                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {study.metrics.map((metric, idx) => (
                      <div key={idx} className="p-4 bg-primary/5 rounded-lg text-center">
                        <div className="text-2xl font-bold text-primary mb-1">{metric.value}</div>
                        <div className="text-sm font-medium mb-1">{metric.label}</div>
                        <div className="text-xs text-muted-foreground">{metric.improvement}</div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="text-center">
                    <Button 
                      onClick={() => generatePDF(study)}
                      disabled={isGenerating}
                      size="lg"
                      className="w-full md:w-auto"
                    >
                      {isGenerating ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                          Generating PDF...
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4 mr-2" />
                          Download Complete Case Study PDF
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl mb-4">
            Downloadable <span className="text-primary">Case Studies</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional PDF versions of my detailed case studies, ready for download and portfolio review
          </p>
        </div>

        <div className="mb-12">
          <Card className="border-2 border-primary/30 bg-primary/5">
            <CardContent className="p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6">
                <FileText className="w-8 h-8 text-primary" />
              </div>
              
              <h3 className="text-xl mb-4">Complete Portfolio Package</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Download all case studies in a single comprehensive PDF document, perfectly formatted for 
                portfolio reviews, interviews, and professional presentations.
              </p>

              <div className="grid md:grid-cols-4 gap-4 mb-8">
                <div className="p-4 bg-background/60 rounded-lg">
                  <div className="text-2xl font-bold text-primary mb-1">$18.5M+</div>
                  <div className="text-sm text-muted-foreground">Combined Revenue Impact</div>
                </div>
                <div className="p-4 bg-background/60 rounded-lg">
                  <div className="text-2xl font-bold text-primary mb-1">2,000+</div>
                  <div className="text-sm text-muted-foreground">Users Impacted</div>
                </div>
                <div className="p-4 bg-background/60 rounded-lg">
                  <div className="text-2xl font-bold text-primary mb-1">4</div>
                  <div className="text-sm text-muted-foreground">Detailed Case Studies</div>
                </div>
                <div className="p-4 bg-background/60 rounded-lg">
                  <div className="text-2xl font-bold text-primary mb-1">3+ Years</div>
                  <div className="text-sm text-muted-foreground">Experience Span</div>
                </div>
              </div>

              <Button 
                onClick={generateAllCaseStudiesPDF}
                disabled={isGenerating}
                size="lg"
                className="w-full md:w-auto"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Generating Complete Portfolio...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Download Complete Portfolio PDF
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          <h2 className="text-2xl text-center mb-8">Individual Case Studies</h2>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {caseStudies.map((study) => (
              <Card key={study.id} className="border-2 border-muted-foreground/20 hover:border-primary/30 transition-colors">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="p-3 rounded-lg bg-primary/10 text-primary">
                        {study.icon}
                      </span>
                      <div>
                        <Badge variant="secondary" className="mb-2 bg-primary/10 text-primary">
                          {study.company}
                        </Badge>
                        <CardTitle className="text-lg">{study.title}</CardTitle>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {study.description}
                  </p>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-muted/50 rounded">
                        <div className="font-semibold text-primary">{study.metrics[0]?.value || 'N/A'}</div>
                        <div className="text-xs text-muted-foreground">{study.metrics[0]?.label || 'Key Metric'}</div>
                      </div>
                      <div className="text-center p-3 bg-muted/50 rounded">
                        <div className="font-semibold text-primary">{study.duration}</div>
                        <div className="text-xs text-muted-foreground">Duration</div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button 
                        onClick={() => setSelectedStudy(study.id)}
                        variant="outline"
                        className="flex-1"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                      <Button 
                        onClick={() => generatePDF(study)}
                        disabled={isGenerating}
                        className="flex-1"
                      >
                        {isGenerating ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-muted/20 border border-primary/20 rounded-lg p-8">
            <h3 className="text-xl mb-4">Need Additional Information?</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              These PDFs contain comprehensive project details including methodology, metrics, and outcomes. 
              For questions about specific projects or additional documentation, feel free to reach out.
            </p>
            <Button variant="outline" asChild>
              <a href="mailto:tymirra@gmail.com?subject=Case Study Questions&body=Hi Tymirra,%0D%0A%0D%0AI have questions about your case studies and would like to discuss them further.%0D%0A%0D%0AThank you!">
                Contact About Case Studies
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}