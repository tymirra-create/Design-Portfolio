import { useState, useEffect } from "react";
import { Button } from "./ui/button.tsx";
import { Card, CardContent } from "./ui/card.tsx";
import { Badge } from "./ui/badge.tsx";
import { Progress } from "./ui/progress.tsx";
import { ChevronLeft, ChevronRight, ExternalLink, Accessibility, Figma, Code, CheckCircle, Palette, Eye, Users, TrendingUp, Target, Zap, Star, Award, Clock, Monitor, MousePointer, Smartphone } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback.tsx";

export function CaseStudiesSlideshow() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      type: "intro",
      title: "Tymirra Smith",
      subtitle: "Senior UI Designer & Accessibility Specialist",
      content: "Pixel Perfect UI & Developer Handoff Excellence",
      role: "Ready to deliver immediate impact for your team",
      expertise: [
        { skill: "Pixel-Perfect UI Design", description: "Precise visual execution with developer-ready specs", icon: Palette },
        { skill: "WCAG 2.1 AA Compliance", description: "Accessibility-first approach with complete documentation", icon: Accessibility },
        { skill: "Developer Handoff Excellence", description: "Comprehensive assets, prototypes, and specifications for smooth implementation", icon: Code }
      ],
      stats: [
        { label: "Years UI Experience", value: "5+", icon: Clock },
        { label: "Accessibility Compliance", value: "100%", icon: Accessibility },
        { label: "Projects Delivered", value: "50+", icon: Target }
      ],
      alignment: "Perfect fit for a role focused on UI polish, accessibility compliance, and developer handoff deliverables"
    },
    {
      type: "portfolio-overview",
      title: "Pixel Perfect Design Portfolio",
      subtitle: "Two Flagship Examples of UI Excellence",
      description: "These designs showcase my expertise in creating polished, accessible interfaces with measurable business impact",
      projects: [
        {
          name: "Window Nation Booking Platform",
          impact: "$3.5M Revenue Generated",
          type: "Enterprise SaaS Platform",
          colorScheme: "burgundy"
        },
        {
          name: "My Credit Approve Platform", 
          impact: "100% WCAG Compliance",
          type: "Financial Services Platform",
          colorScheme: "teal"
        }
      ],
      note: "Both projects include complete Figma files with developer handoff documentation"
    },
    {
      type: "project-showcase",
      title: "Window Nation: $3.5M Revenue Platform",
      subtitle: "Enterprise Booking System with Complete Design System",
      image: "https://images.unsplash.com/photo-1643781410046-421dd014f743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kb3clMjBob21lJTIwaW1wcm92ZW1lbnQlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4MDM3MDE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      figmaUrl: "https://www.figma.com/deck/mgxwJFmkrorBKWAzQDJW4Q/Design-Review?node-id=1-511&viewport=-107%2C-42%2C0.51&t=kLdlKwO0RI70hCjQ-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1",
      role: "Senior UX Designer & Team Lead",
      duration: "6 months",
      teamSize: "4 designers",
      colorScheme: "burgundy",
      deliverables: [
        "Complete design system with 50+ components",
        "Responsive booking flow with 8 steps",
        "Microsoft Dynamics CRM integration specs",
        "Accessibility annotations for every interaction",
        "Developer handoff with precise measurements",
        "Cross-platform design tokens & assets"
      ],
      uiFeatures: [
        "Pixel-perfect component library",
        "Mobile-responsive breakpoints", 
        "Interactive form validation states",
        "Loading states and micro-animations",
        "Error handling and empty states",
        "Focus management and keyboard navigation"
      ],
      impact: [
        { metric: "Revenue Generated", value: "$3.5M", icon: TrendingUp },
        { metric: "Team Members Led", value: "4", icon: Users },
        { metric: "Components Created", value: "50+", icon: Palette },
        { metric: "Accessibility Score", value: "100%", icon: Accessibility }
      ],
      businessValue: "Led complete UI overhaul that resulted in $3.5M revenue increase through optimized booking conversion"
    },
    {
      type: "project-showcase",
      title: "My Credit Approve: Financial Platform",
      subtitle: "Accessibility-First Design with Complete WCAG Compliance",
      image: "https://images.unsplash.com/photo-1757301714935-c8127a21abc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVkaXQlMjBmaW5hbmNpYWwlMjBhcHAlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4MDM3MDE4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      figmaUrl: "https://visor-found-65128644.figma.site/",
      role: "UI Designer & Accessibility Consultant",
      duration: "4 months", 
      compliance: "SOX & WCAG 2.1 AA",
      colorScheme: "teal",
      deliverables: [
        "Mobile-first responsive design system",
        "Credit dispute flow with 12 steps",
        "High contrast mode support",
        "Screen reader optimized components",
        "Complete accessibility audit documentation",
        "Interactive prototype with user testing results"
      ],
      uiFeatures: [
        "Clean, minimal interface design",
        "Step-by-step progress indicators",
        "Touch-friendly mobile interactions",
        "Advanced form validation patterns",
        "Data visualization accessibility",
        "Multi-language support ready"
      ],
      impact: [
        { metric: "WCAG Compliance", value: "100%", icon: Accessibility },
        { metric: "Mobile Score", value: "98/100", icon: Smartphone },
        { metric: "User Testing", value: "4.8/5", icon: Star },
        { metric: "Load Time", value: "<2s", icon: Zap }
      ],
      businessValue: "Delivered fully accessible financial platform meeting all compliance requirements with exceptional user experience"
    },
    {
      type: "ui-details",
      title: "UI Execution Excellence",
      subtitle: "Attention to Every Pixel & Interaction",
      sections: [
        {
          title: "Design System Components",
          icon: Palette,
          details: [
            "Pixel-perfect spacing using 8px grid system",
            "Consistent typography scale with accessibility ratios",
            "Color palette with WCAG AA contrast compliance",
            "Interactive states for all UI elements",
            "Responsive breakpoint specifications",
            "Icon library with consistent styling"
          ]
        },
        {
          title: "Accessibility Integration",
          icon: Accessibility,
          details: [
            "Screen reader optimized markup specifications",
            "Keyboard navigation and focus management",
            "Alternative text for all visual elements",
            "High contrast mode support",
            "Touch target size compliance (44px minimum)",
            "Error messaging and form validation patterns"
          ]
        },
        {
          title: "Developer Handoff",
          icon: Code,
          details: [
            "Figma Dev Mode with inspect-ready components",
            "CSS custom properties and design tokens",
            "Interaction specifications and animations",
            "Cross-browser compatibility notes",
            "Performance optimization guidelines",
            "Testing scenarios and acceptance criteria"
          ]
        }
      ]
    },
    {
      type: "figma-showcase",
      title: "Interactive Figma Prototypes",
      subtitle: "Complete Design Documentation & Handoff Assets",
      description: "Both projects include comprehensive Figma files with pixel-perfect specifications, interactive prototypes, and complete developer handoff documentation",
      projects: [
        {
          name: "Window Nation Platform",
          description: "Complete design system with booking flow and CRM integration",
          url: "https://www.figma.com/deck/mgxwJFmkrorBKWAzQDJW4Q/Design-Review?node-id=1-511&viewport=-107%2C-42%2C0.51&t=kLdlKwO0RI70hCjQ-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1",
          features: ["Interactive Prototype", "Design System", "Developer Specs", "Accessibility Notes"],
          colorScheme: "burgundy",
          image: "https://images.unsplash.com/photo-1643781410046-421dd014f743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kb3clMjBob21lJTIwaW1wcm92ZW1lbnQlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4MDM3MDE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        },
        {
          name: "My Credit Approve Platform",
          description: "Accessibility-first financial platform with complete WCAG compliance",
          url: "https://visor-found-65128644.figma.site/",
          features: ["Accessibility Audit", "Mobile Responsive", "User Testing Results"],
          colorScheme: "teal",
          image: "https://images.unsplash.com/photo-1757301714935-c8127a21abc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8Y3JlZGl0JTIwZmluYW5jaWFsJTIwYXBwJTIwaW50ZXJmYWNlfGVufDF8fHx8MTc1ODAzNzAxOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        }
      ],
      note: "Click the links above to view live prototypes and design documentation"
    },
    {
      type: "value-proposition",
      title: "Why I'm Perfect for This Role",
      subtitle: "6-Month Contract Impact & Immediate Value",
      alignment: [
        {
          requirement: "Pixel-Perfect UI Execution",
          evidence: "Window Nation: 50+ components with precise specifications",
          impact: "Ready to polish existing UI to production standards",
          icon: Palette
        },
        {
          requirement: "Accessibility Compliance",
          evidence: "My Credit Approve: 100% WCAG 2.1 AA compliance achieved",
          impact: "Eliminate accessibility risks and ensure compliance",
          icon: Accessibility
        },
        {
          requirement: "Developer Handoff Excellence", 
          evidence: "Both projects: Complete Figma Dev Mode documentation",
          impact: "Smooth implementation with minimal questions and clear prototypes for seamless developer communication",
          icon: Code
        },
        {
          requirement: "Senior-Level Independence",
          evidence: "Led 4-person team, delivered $3.5M revenue impact",
          impact: "Take full ownership of UI deliverables",
          icon: Star
        }
      ],
      availability: "Available to start immediately",
      commitment: "Passionate about pixel-perfect details and accessibility excellence",
      roi: "Proven track record of 3x ROI through reduced development time and rework"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === ' ') {
        event.preventDefault();
        nextSlide();
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        prevSlide();
      } else if (event.key >= '1' && event.key <= '9') {
        const slideIndex = parseInt(event.key) - 1;
        if (slideIndex < slides.length) {
          setCurrentSlide(slideIndex);
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  const renderSlideContent = () => {
    const slide = slides[currentSlide];

    switch (slide.type) {
      case "intro":
        return (
          <div className="text-center space-y-8">
            <div className="space-y-6">
              <h1 className="text-5xl font-bold text-primary">{slide.title}</h1>
              <h2 className="text-2xl text-burgundy">{slide.subtitle}</h2>
              <p className="text-xl text-muted-foreground">{slide.content}</p>
              <p className="text-lg text-terracotta font-semibold">{slide.role}</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6 my-12">
              {slide.expertise?.map((item, i) => (
                <Card key={i} className="p-6 border-2 border-warm-cream hover:border-terracotta transition-colors">
                  <CardContent className="p-0 text-center">
                    <div className="mb-4">
                      <item.icon className="w-10 h-10 mx-auto text-terracotta" />
                    </div>
                    <h3 className="font-semibold text-burgundy mb-2">{item.skill}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {slide.stats?.map((stat, i) => (
                <div key={i} className="bg-warm-cream p-6 rounded-lg text-center">
                  <div className="mb-3">
                    <stat.icon className="w-8 h-8 mx-auto text-terracotta" />
                  </div>
                  <div className="text-2xl font-bold text-burgundy">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
            
            <div className="bg-terracotta/10 p-6 rounded-lg border border-terracotta/30">
              <p className="text-burgundy font-semibold">{slide.alignment}</p>
            </div>
          </div>
        );

      case "portfolio-overview":
        return (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-primary mb-4">{slide.title}</h1>
              <h2 className="text-xl text-muted-foreground mb-6">{slide.subtitle}</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">{slide.description}</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {slide.projects?.map((project, i) => (
                <Card key={i} className={`p-8 border-2 text-center ${
                  project.colorScheme === 'burgundy' ? 'border-burgundy/30 bg-burgundy/5' : 'border-teal/30 bg-teal/5'
                }`}>
                  <CardContent className="p-0">
                    <div className="mb-6">
                      <div className={`w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center ${
                        project.colorScheme === 'burgundy' ? 'bg-burgundy/20' : 'bg-teal/20'
                      }`}>
                        <Palette className={`w-8 h-8 ${
                          project.colorScheme === 'burgundy' ? 'text-burgundy' : 'text-teal'
                        }`} />
                      </div>
                      <h3 className="text-xl font-bold text-burgundy mb-2">{project.name}</h3>
                      <Badge className={`mb-3 ${
                        project.colorScheme === 'burgundy' ? 'bg-burgundy text-white' : 'bg-teal text-white'
                      }`}>
                        {project.impact}
                      </Badge>
                      <p className="text-sm text-muted-foreground">{project.type}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center bg-warm-cream p-6 rounded-lg">
              <p className="text-burgundy font-semibold">{slide.note}</p>
            </div>
          </div>
        );

      case "project-showcase":
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <h1 className="text-3xl font-bold text-primary mb-2">{slide.title}</h1>
              <h2 className="text-lg text-burgundy mb-4">{slide.subtitle}</h2>
              <div className="flex justify-center gap-4 flex-wrap mb-6">
                <Badge variant="outline" className="text-sm text-terracotta border-terracotta">{slide.role}</Badge>
                <Badge className={`${slide.colorScheme === 'burgundy' ? 'bg-burgundy' : 'bg-teal'} text-white`}>
                  {slide.duration}
                </Badge>
                {slide.teamSize && <Badge className="bg-warm-cream text-burgundy">{slide.teamSize}</Badge>}
                {slide.compliance && <Badge className="bg-warm-cream text-burgundy">{slide.compliance}</Badge>}
              </div>
            </div>

            {/* Project Image */}
            <div className="relative mb-6">
              <Card className="overflow-hidden border-2 border-warm-cream">
                <ImageWithFallback
                  src={slide.image}
                  alt={`${slide.title} design preview`}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 right-4">
                  <Button 
                    asChild 
                    size="sm"
                    className={`${slide.colorScheme === 'burgundy' ? 'bg-burgundy hover:bg-burgundy/90' : 'bg-teal hover:bg-teal/90'} text-white`}
                  >
                    <a href={slide.figmaUrl} target="_blank" rel="noopener noreferrer">
                      <Figma className="w-4 h-4 mr-2" />
                      View in Figma
                    </a>
                  </Button>
                </div>
              </Card>
            </div>

            {/* Impact Metrics */}
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              {slide.impact?.map((metric, i) => (
                <div key={i} className="bg-warm-cream p-4 rounded-lg text-center">
                  <metric.icon className="w-6 h-6 mx-auto text-terracotta mb-2" />
                  <div className="text-lg font-bold text-burgundy">{metric.value}</div>
                  <div className="text-xs text-muted-foreground">{metric.metric}</div>
                </div>
              ))}
            </div>

            {/* Deliverables and Features */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6 border-2 border-warm-cream">
                <CardContent className="p-0">
                  <div className="flex items-center gap-2 mb-4">
                    <Figma className="w-5 h-5 text-terracotta" />
                    <h3 className="font-semibold text-burgundy">Design Deliverables</h3>
                  </div>
                  <div className="space-y-2">
                    {slide.deliverables?.map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-teal mt-0.5 flex-shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6 border-2 border-warm-cream">
                <CardContent className="p-0">
                  <div className="flex items-center gap-2 mb-4">
                    <Monitor className="w-5 h-5 text-teal" />
                    <h3 className="font-semibold text-burgundy">UI Features</h3>
                  </div>
                  <div className="space-y-2">
                    {slide.uiFeatures?.map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-teal mt-0.5 flex-shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Business Value */}
            <div className={`${slide.colorScheme === 'burgundy' ? 'bg-burgundy/10 border-burgundy/30' : 'bg-teal/10 border-teal/30'} p-6 rounded-lg border text-center`}>
              <p className="font-semibold text-burgundy">{slide.businessValue}</p>
            </div>
          </div>
        );

      case "ui-details":
        return (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-primary mb-2">{slide.title}</h1>
              <h2 className="text-xl text-muted-foreground">{slide.subtitle}</h2>
            </div>

            <div className="space-y-8">
              {slide.sections?.map((section, i) => (
                <Card key={i} className="p-6 border-2 border-warm-cream">
                  <CardContent className="p-0">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="bg-terracotta/10 p-3 rounded-full">
                        <section.icon className="w-6 h-6 text-terracotta" />
                      </div>
                      <h3 className="text-xl font-semibold text-burgundy">{section.title}</h3>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      {section.details.map((detail, j) => (
                        <div key={j} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-teal mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{detail}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        );

      case "figma-showcase":
        return (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-primary mb-2">{slide.title}</h1>
              <h2 className="text-xl text-muted-foreground mb-4">{slide.subtitle}</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">{slide.description}</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {slide.projects?.map((project, i) => (
                <Card key={i} className={`overflow-hidden border-2 hover:shadow-xl transition-all duration-300 ${
                  project.colorScheme === 'burgundy' ? 'border-burgundy/30 hover:border-burgundy/50' : 'border-teal/30 hover:border-teal/50'
                }`}>
                  <div className="relative">
                    <ImageWithFallback
                      src={project.image}
                      alt={`${project.name} preview`}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-white font-semibold text-lg mb-1">{project.name}</h3>
                      <p className="text-white/80 text-sm">{project.description}</p>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        {project.features.map((feature, j) => (
                          <Badge key={j} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                      
                      <Button 
                        asChild 
                        className={`w-full ${
                          project.colorScheme === 'burgundy' ? 'bg-burgundy hover:bg-burgundy/90' : 'bg-teal hover:bg-teal/90'
                        } text-white`}
                      >
                        <a href={project.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View Live Prototype
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center bg-warm-cream p-6 rounded-lg">
              <p className="text-burgundy font-semibold">{slide.note}</p>
            </div>
          </div>
        );

      case "value-proposition":
        return (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-primary mb-2">{slide.title}</h1>
              <h2 className="text-xl text-muted-foreground">{slide.subtitle}</h2>
            </div>

            <div className="space-y-6">
              {slide.alignment?.map((item, i) => (
                <Card key={i} className="p-6 border-l-4 border-l-teal">
                  <CardContent className="p-0">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 bg-teal/10 p-3 rounded-full">
                        <item.icon className="w-6 h-6 text-teal" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-burgundy mb-2">{item.requirement}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{item.evidence}</p>
                        <p className="text-sm font-medium text-terracotta">{item.impact}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-terracotta p-6 rounded-lg text-center text-white">
                <h3 className="font-semibold mb-2">Availability</h3>
                <p className="text-sm">{slide.availability}</p>
              </div>
              <div className="bg-burgundy p-6 rounded-lg text-center text-white">
                <h3 className="font-semibold mb-2">ROI</h3>
                <p className="text-sm">{slide.roi}</p>
              </div>
              <div className="bg-teal p-6 rounded-lg text-center text-white">
                <h3 className="font-semibold mb-2">Commitment</h3>
                <p className="text-sm">{slide.commitment}</p>
              </div>
            </div>
          </div>
        );


      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-warm-cream/10 to-background flex flex-col">
      {/* Progress bar */}
      <div className="w-full bg-warm-cream/30 h-2">
        <div 
          className="h-full bg-gradient-to-r from-burgundy to-terracotta transition-all duration-300"
          style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
        />
      </div>

      <div className="flex-1 flex items-center justify-center p-4 md:p-8">
        <Card className="w-full max-w-6xl min-h-[700px] shadow-xl border-2 border-warm-cream">
          <CardContent className="p-8 md:p-12 flex flex-col justify-center">
            {renderSlideContent()}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between p-4 md:p-6 bg-warm-cream/20">
        <Button 
          onClick={prevSlide} 
          variant="outline" 
          size="sm"
          className="border-burgundy text-burgundy hover:bg-burgundy hover:text-white"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>
        
        <div className="flex items-center gap-4">
          <div className="flex gap-1">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full transition-all duration-200 ${
                  index === currentSlide 
                    ? 'bg-burgundy w-8' 
                    : 'bg-burgundy/30 hover:bg-burgundy/60 w-2'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground hidden md:inline">
            {currentSlide + 1} / {slides.length}
          </span>
        </div>

        <Button 
          onClick={nextSlide} 
          variant="outline" 
          size="sm"
          className="border-burgundy text-burgundy hover:bg-burgundy hover:text-white"
        >
          Next
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      {/* Keyboard shortcuts hint */}
      <div className="text-center py-3 text-xs text-muted-foreground bg-warm-cream/20">
        <div className="flex justify-center gap-4 flex-wrap">
          <span>⬅️➡️ Navigate</span>
          <span>Space: Next</span>
          <span>1-7: Jump to slide</span>
        </div>
      </div>
    </div>
  );
}