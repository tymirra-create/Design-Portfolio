import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Calendar, MapPin, Building } from "lucide-react";

export function Experience() {
  const experiences = [
    {
      title: "Senior Product Designer",
      company: "Window Nation",
      location: "Remote",
      period: "April 2024 - May 2025",
      type: "Full-time",
      description: "Led digital transformation of lead generation strategy, resulting in $3.5M revenue impact. Designed and launched online appointment booking platform with Microsoft Dynamics integration.",
      achievements: [
        "Generated $3.5M+ in revenue through digital transformation",
        "Reduced lead response time by 60%",
        "Mentored team of 3 interns through complete product lifecycle",
        "Improved lead-to-appointment conversion by 35%"
      ],
      skills: ["Product Strategy", "Team Leadership", "Enterprise UX", "Revenue Generation"]
    },
    {
      title: "Lead UX Researcher",
      company: "ServiceMaster Brands",
      location: "Remote",
      period: "Nov 2021 - April 2024",
      type: "Full-time",
      description: "Conducted comprehensive user research across multiple brands, designing data-driven solutions that improved franchisee operations and conversion rates.",
      achievements: [
        "Conducted 50+ stakeholder interviews across 3 brands",
        "Designed business intelligence dashboards for 2,000+ franchisees",
        "Achieved 12% conversion improvement on optimized lead forms",
        "Collaborated daily with data analysts and brand presidents"
      ],
      skills: ["User Research", "Data Analysis", "Business Intelligence", "Stakeholder Management"]
    }
  ];

  return (
    <section id="experience" className="py-20 px-6 bg-muted/10">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="mb-4">Professional Experience</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Driving measurable business impact through strategic design and user research
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card key={index} className="border-l-4 border-l-primary">
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div>
                    <CardTitle className="text-xl text-primary">{exp.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Building className="w-4 h-4 text-muted-foreground" />
                      <span className="text-lg font-semibold">{exp.company}</span>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {exp.period}
                    </Badge>
                    <Badge variant="outline" className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {exp.location}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6">{exp.description}</p>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-3">Key Achievements</h4>
                    <ul className="space-y-2">
                      {exp.achievements.map((achievement, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-3">Core Skills</h4>
                    <div className="flex flex-wrap gap-2">
                      {exp.skills.map((skill, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}